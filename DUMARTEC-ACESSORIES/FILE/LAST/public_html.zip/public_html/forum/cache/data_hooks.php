<?php
$expired = (time() > 1266988572) ? true : false;
if ($expired) { return; }

$data =  array();

?>