<?php

$dbms     = 'mysql'       ;
$dbhost   = 'localhost' ;
$dbport   = ''            ;
$dbname   = 'dumarcom_phpb1'   ;
$dbuser   = 'dumarcom_phpb1' ;
$dbpasswd = 'Z8uiOyhzcNtf' ;

$table_prefix    = 'phpbb_' ;
$acm_type        = 'file'   ;
$load_extensions = ''       ;

@define('PHPBB_INSTALLED', true);

?>