<?php
error_reporting(0);
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$_MAMBOTS->registerFunction( 'onStart' , 'JGFloodScan' );
$_MAMBOTS->registerFunction( 'onAfterStart' , 'JGInjectionScan' );


function JGFloodScan()
{
	global $mosConfig_mailfrom, $database;
  $sql="SELECT * FROM #__jguard_options Where id=1";
		$database->setQuery($sql);
    $options=$database->loadAssocList();
    if(find_blocks_OnStart())
	{
		$ip = getenv ("REMOTE_ADDR");
		$referer = parse_url(getenv ("http_referer")); $referer=$referer['host'];
		$email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
		include( 'mambots/system/jguard_message_page.php' );
		print for_blocked_user($ip,$referer,$email);
		
		/*print'<table width="100%" height="95%"><tr><td valign="center" align=center><b><font color="#c64934">�� ���� ���� �������� ��������� ���������</font></b>.<br>�������� �� �������� � ������������� ���������� �������� �����, ������� <b><font color="#c64934">�� � ������ ������ �������������</font></b>.<br>��������� �� ���� ���� ������� �������������� � ��, ���� ������ ������, ������������ ���.</td></tr></table>';*/
		exit;
	}
	if(FloodScan()) //�������� �� ����������� ������� ������ ����� ���� Flood
	{
  
		$ip = getenv ("REMOTE_ADDR");
		$referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
		$email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
		
		include( 'mambots/system/jguard_message_page.php' );
		print for_flood($ip,$referer,$email);
		
		/*print'<table width="100%" height="95%"><tr><td valign="center" align=center><b><font color="#c64934">�� ������� ����� ������������ ���������</font></b>, ��� ���� ������� �������� �� ������.<br>�������� �� Flooder � ��� �������������� �����, �� ����� <b><font color="#c64934">�� � ������ ������ �������������</font></b>.<br>��������� �� ���� ���������� ������������� �, ���� ������ ������, �� ������������ ���.</td></tr></table>';*/
		exit;
	}
}
	
function JGInjectionScan()
{
	global $database, $mainframe, $mosConfig_mailfrom;
	
	if(find_blocks_OnAfterStart())
	{
		$ip = getenv ("REMOTE_ADDR");
		$referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
		$email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
		
		include( 'mambots/system/jguard_message_page.php' );
		print for_blocked_user($ip,$referer,$email,1);
		
		/*print'<table width="100%" height="95%"><tr><td valign="center" align=center><b><font color="#c64934">�� ���� ���� �������� ��������� ���������</font></b>.<br>�������� �� �������� � ������������� ���������� �������� �����, ������� <b><font color="#c64934">�� � ������ ������ �������������</font></b>.<br>��������� �� ���� ���� ������� �������������� � ��, ���� ������ ������, ������������ ���.</td></tr></table>';*/
		exit;
	}
// My Script starts HERE *************************************************************************	
	$my = $mainframe->getUser();
  
  
	if(isset($my)){$user_id = $my->id;}
  else {$user_id=$my->id;}
  
	$database->setQuery("select * from #__jguard_options");
	$options=$database->loadAssocList();

	$UserIp=getenv ("REMOTE_ADDR");
	
	$block=false;

#SEARCHING FOR MYSQL INJECTIONS START *************************************************	
      if ($options[0][mysql_scan]==1){
      $keywords = $options[0][mysql_keywords];
      $keywords = explode("\n",str_replace("\r",'',$keywords));
        foreach($_REQUEST as $val){
          foreach($keywords as $keyword){
             if (preg_match($keyword, $val) and $_REQUEST['task']!=$keyword and $_REQUEST['act']!=$keyword and $_GET['option']!=$keyword){
                if (eregi(0,$options[0][mysql_parameter]) and !eregi(1,$options[0][mysql_parameter]) and !eregi(2,$options[0][mysql_parameter]) and !eregi(3,$options[0][mysql_parameter]))
                {
                
                $ip = getenv ("REMOTE_ADDR");
                $referer = parse_url(getenv ("http_referer"));
                $referer=$referer['host'];
                $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
                if($options[0][send_email]==1 and $options[0][send_mysql_injection]==1){
                  $message.="<div align='center'><b>The attack of type Mysql Injection was Discovered on your site. </b></div>";
                  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$ip."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
                  @send_mail("send_php_injection","The attack of type Mysql Injection was Discovered on your site.",$message);
                  }
                write_log('mysql injection', 'suspect');
                }
                if(eregi(1,$options[0][mysql_parameter]) and eregi(0,$options[0][mysql_parameter])) {//SUSPECT
                include( 'mambots/system/jguard_message_page.php');
                $ip = getenv ("REMOTE_ADDR");
                $referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
                $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
                if($options[0][send_email]==1 and $options[0][send_mysql_injection]==1){
                  $message.="<div align='center'><b>The attack of type Mysql Injection was Discovered on your site. </b></div>";
                  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$ip."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
                  @send_mail("send_php_injection","The attack of type Mysql Injection was Discovered on your site.",$message);
                  }
                write_log('mysql injection', 'reject');
                print for_injection($ip,$referer,$email);
                exit;
              } if (eregi(1,$options[0][mysql_parameter]) and !eregi(0,$options[0][mysql_parameter])){
                include( 'mambots/system/jguard_message_page.php');
                $ip = getenv ("REMOTE_ADDR");
                $referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
                $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
                if($options[0][send_email]==1 and $options[0][send_mysql_injection]==1){
                  $message.="<div align='center'><b>The attack of type Mysql Injection was Discovered on your site. </b></div>";
                  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$ip."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
                  @send_mail("send_php_injection","The attack of type Mysql Injection was Discovered on your site.",$message);
                  }
                  write_log('mysql injection', 'reject');
                print for_injection($ip,$referer,$email);
              }
               if(eregi(2,$options[0][mysql_parameter]) and eregi(3,$options[0][mysql_parameter])) {//BLOCK IP
                include( 'mambots/system/jguard_message_page.php' );
                $ip = getenv ("REMOTE_ADDR");
                $referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
                $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
                if($options[0][send_email]==1 and $options[0][send_mysql_injection]==1){
                  $message.="<div align='center'><b>The attack of type Mysql Injection was Discovered on your site. </b></div>";
                  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$ip."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
                  @send_mail("send_php_injection","The attack of type Mysql Injection was Discovered on your site.",$message);
                  }
                write_log('mysql injection', 'reject');
                blocking("login",$user_id);
                blocking("ip",$UserIp);
                print for_blocked_user($ip,$referer,$email);
                exit;
                }
              if(eregi(2,$options[0][mysql_parameter])) {//BLOCK IP
                include( 'mambots/system/jguard_message_page.php' );
                $ip = getenv ("REMOTE_ADDR");
                $referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
                $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
                if($options[0][send_email]==1 and $options[0][send_mysql_injection]==1){
                  $message.="<div align='center'><b>The attack of type Mysql Injection was Discovered on your site. </b></div>";
                  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$UserIp."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
                  @send_mail("send_php_injection","The attack of type Mysql Injection was Discovered on your site.",$message);
                  }
                write_log('mysql injection', 'reject');
                blocking("ip",$UserIp);
                print for_blocked_user($ip,$referer,$email);
                exit;
              } if (eregi(3,$options[0][mysql_parameter])) {//BLOCK LOGIN
                include( 'mambots/system/jguard_message_page.php' );
                $ip = getenv ("REMOTE_ADDR");
                $referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
                $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
                if($options[0][send_email]==1 and $options[0][send_mysql_injection]==1){
                  $message.="<div align='center'><b>The attack of type Mysql Injection was Discovered on your site. </b></div>";
                  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$ip."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
                  @send_mail("send_php_injection","The attack of type Mysql Injection was Discovered on your site.",$message);
                  }
                blocking("login",$user_id);
                write_log('mysql injection', 'reject');
                print for_blocked_user($ip,$referer,$email);
                exit;
              }
                           
            }
          }
        }
      }
#SEARCHING FOR  MYSQL INJECTIONS END ***************************************************  
#SCANNIN THE FILES *********************************************************************
      if ($options[0][file_scan]==1){
    		if (isset($_FILES)){
    			foreach($_FILES as $key=>$val){
    				$fp=fopen($_FILES[$key]['tmp_name'], "r");
    				$file_content=fread($fp,10000000);
    				if(eregi("<\?php|\?>",$file_content)){
            include( 'mambots/system/jguard_message_page.php' );
            $ip = getenv ("REMOTE_ADDR");
            $referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
            $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
            if($options[0][send_email]==1 and $options[0][send_file_injection]==1){
            $message.="<div align='center'><b>The attack of type PHP Injection was Discovered on your site.. </b></div>";
            $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$UserIp."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
            @send_mail("send_php_injection","The attack of type PHP Injection was Discovered on your site.",$message);
            print for_injection($ip,$referer,$email,0);
    							if (eregi(0,$options[0][file_parameter])){
                  include( 'mambots/system/jguard_message_page.php' );
                  $ip = getenv ("REMOTE_ADDR");
                  $referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
                  $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
                  if($options[0][send_email]==1 and $options[0][send_file_injection]==1){
                  $message.="<div align='center'><b>The attack of type PHP Injection was Discovered on your site.. </b></div>";
                  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$UserIp."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
                  @send_mail("send_php_injection","The attack of type PHP Injection was Discovered on your site.",$message);
                  }
                  blocking('login',$user_id);
                  print for_injection($ip,$referer,$email,0);
                  }
                  if (eregi(1,$options[0][file_parameter])){
                  include( 'mambots/system/jguard_message_page.php' );
                  $ip = getenv ("REMOTE_ADDR");
                  $referer = parse_url(getenv ("http_referer"));$referer=$referer['host'];
                  $email = '<a href="mailto:'.$mosConfig_mailfrom.'">'.$mosConfig_mailfrom.'</a>';
                  if($options[0][send_email]==1 and $options[0][send_file_injection]==1){
                  $message.="<div align='center'><b>The attack of type PHP Injection was Discovered on your site.. </b></div>";
                  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$UserIp."</td></tr><tr><td><b>Login</b></td><td>".$my->name."</td></tr><tr><td><b>Email</b></td><td>".$my->email."</td></tr><tr><td><b>Register Date</b></td><td>".$my->registerDate."</td></tr></table>";
                  @send_mail("send_php_injection","The attack of type PHP Injection was Discovered on your site.",$message);
                  }
                  blocking('ip',$ip);
                  print for_blocked_user($ip,$referer,$email,1);
                  
                  }
    				}
    				fclose($fp);
    			}
    		}
    	}
#SCANNING THE FILES END **********************************************************************
# MY SCRIPT ENDS HERE *************************************************************************
	}
		
}

function send_mail($type,$subject,$text)
{
	global $database;
	$database->setQuery("select * from #__jguard_options");
	$options=$database->loadAssocList();
	if($options[0]["send_email"]==1)
	{
		/*"send_php_injection"
		"send_mysql_injection"
		"send_flood"*/
		
		
			$headers .= "From: JGuard\n";
			$headers .= "X-Mailer: PHP\n"; // mailer
			$headers .= "X-Priority: 1\n"; // Urgent message!
			$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type
			@mail($options[0]["email"], $subject, $text, $headers);
		
	}
}

function find_blocks_OnAfterStart()
{
	global $database, $mainframe;
	$my = $mainframe->getUser();
	
	if(isset($my))	{ $user_id=$my->id; }
	else { $user_id='';}
	$UserIp=getenv ("REMOTE_ADDR");
	
	$query="select count(`type`) from #__jguard_block_list where ";
	$query.=" `type` = 'login' and `value` = '".$user_id."' ";
	
	$database->setQuery($query);
	$user_data=$database->loadObjectList();
	$count_blocks = $database->loadResult();
	
	if ($count_blocks>0){ return true; }
	else				{ return false; }
}


function find_blocks_OnStart()
{
	global $database;

	$UserIp=getenv ("REMOTE_ADDR");
	
	$query="select count(`type`) from #__jguard_block_list where ";
	$query.=" (`type` = 'ip' and `value` = '".$UserIp."') ";
		$gets="";
	    reset ($_GET);
	    $count=0;
		while (list ($key, $val) = each ($_GET))
	    {
	    	if(in_array($key,array(''))=='')
	        {
	        	$count++;
	            if($count>1){$gets.=" or ";}
	            $gets.="`value`='".$key."=".$val."'";
	        }
		}
	if($gets){$query.=" or (`type` = 'get' and (".$gets.")) ";}
		$posts="";
	    reset ($_POST);
	    $count=0;
		while (list ($key, $val) = each ($_POST))
	    {
	    	if(in_array($key,array(''))=='')
	        {
	        	$count++;
	            if($count>1){$posts.=" or ";}
	            $posts.="`value`='".$key."=".$val."'";
	        }
		}
	if($posts){$query.=" or (`type` = 'post' and (".$posts.")) ";}
	//$query.=" or (`type` = 'login' and `value` = '".$user_id."') ";
	$referer=parse_url(getenv ("http_referer"));
	$query.=" or (`type` = 'referer' and `value` = '".$referer['host']."') ";
	
	$database->setQuery($query);
	$user_data=$database->loadObjectList();
	$count_blocks = $database->loadResult();
	
	if ($count_blocks>0){ return true; }
	else				{ return false; }
}
function FloodScan()
{
	global $database;
 	$flood=false;
  $description='';
	$database->setQuery("select * from #__jguard_options");
	$options=$database->loadAssocList();
	
	$UserIp=getenv("REMOTE_ADDR");
	
	$database->setQuery("DELETE FROM `#__jguard_flood_monitor` WHERE `time` < (now() - INTERVAL 1 DAY)");
	$database->query();
	
	if($options[0]["untiflood"]==1)
	{
		$database->setQuery("insert into #__jguard_flood_monitor (`ip`,`time`) values ('".$UserIp."',now())");
		$database->query();
		
		for($i=1;$i<=3;$i++)
		{
			if($options[0]["flood_queries_".$i] >0 && $options[0]["flood_time_".$i] >0)
			{
				$database->setQuery("select count(ip) from #__jguard_flood_monitor where `ip`='".$UserIp."' and `time`>=now()-INTERVAL ".$options[0]["flood_time_".$i]." SECOND");
				$count_queries = $database->loadResult();
				if ($count_queries>=$options[0]["flood_queries_".$i])
				{
            
          
//��������� log suspect
					
					if (eregi(1,$options[0][flood_parameter])){
					blocking("ip",$UserIp); //��������� ip ������������
          }
					$flood=true;
				}
			}
		}
    if ($flood==true){
    if (eregi(1,$options[0][flood_parameter])){
					$descripton="Blocked on commecing the attack of type flood(the rule: not more ".$options[0]["flood_queries_".$i]." queries in ".$options[0]["flood_time_".$i]." seconds)";
          }
          else {
          $descripton=" Rejected on commecing the attack of type flood(the rule: not more ".$options[0]["flood_queries_".$i]." queries in ".$options[0]["flood_time_".$i]." seconds)";
          }
			$database->setQuery("Select `ip`, `type` from #__jguard_log  order by `id` desc limit 1");
      $value = $database->loadAssocList();
      if (($value[0]['ip']!=$UserIp and $value[0]['type']!='flood')){//|| $value[0]['type']!='flood' ){
      
  $UserIp = getenv ("REMOTE_ADDR");
  $database->setQuery("insert into #__jguard_log (`ip`, `ctime`, `type`, `description`,`suspect_reject`) values ('".$UserIp."',now(),'flood','".$descripton."','reject' )");
  $database->query();    
  if($options[0][send_email]==1 and $options[0][send_flood]==1){
  $UserIp=getenv("REMOTE_ADDR");
  $message.="<div align='center'><b>The attack of type Flood was Discovered on your site.</b></div>";
  $message.="Information about the suspect:<table><tr><td><b>Ip</b></td><td>".$UserIp."</td></tr></table>";
  @send_mail("send_flood","The attack of type Flood was Discovered on your site.",$message);
  }
    }
    }
	}
      
	return $flood;
}

function injection_blocking()
{
	global $database, $mainframe;
	$database->setQuery("select * from #__jguard_options");
	$options=$database->loadAssocList();
	
	$my = $mainframe->getUser();
	if(isset($my))	{ $user_id=$my->id; }
	else { $user_id=''; }
	$UserIp=getenv ("REMOTE_ADDR");
	$referer=parse_url(getenv ("http_referer"));
	if($options[0]["block_injections"]==1)
	{
		if($options[0]["block_ip"]==1)		{blocking("ip",$UserIp);}
		if($options[0]["block_login"]==1)	{blocking("login",$user_id);}
		if($options[0]["block_referer"]==1)	{blocking("referer",$referer["host"]);}
	}
}
function blocking($type,$value)
{
	global $database;
	if($value)
	{
		$database->setQuery("select count(type) from #__jguard_block_list where `type`='".$type."' and `value`= '".$value."'");
		$count_rows = $database->loadResult();
		if($count_rows == 0)
		{
			$database->setQuery("insert into #__jguard_block_list (`type`, `value`) values ('".$type."','".$value."')");
			$database->query();
		}
	}
}

function write_log($type,$log)
{ 
  global $database, $mainframe, $my;
  
 if ($type!='flood'){ 
	$my = $mainframe->getUser();
  $UserIp=getenv ("REMOTE_ADDR");
	if(isset($my)){$user_id = $my->id;}
	else { $user_id=''; }
  }
	$gets=all_GETs();
	$url=$_SERVER["PHP_SELF"];
	if($gets){$url=$url.'?'.$gets;}
	
	$database->setQuery("insert into #__jguard_log (`ip`, `ctime`, `type`, `user_id`, `url`, `post`, `cook`, `referer`, `description`,`suspect_reject`) ".
							"values ('".$UserIp."',now(),'".$type."','".$user_id."','".$url."','".all_POSTs()."','','".getenv ("http_referer")."','','".$log."')");
	$database->query();
}
function all_POSTs($cansels=array('')) //������ ������, ���������� ��� ������� ������� $_POST � ����������� "&" ����� ������������� � ������� $cansels
{
	$res="";
    reset ($_POST);
    $count=0;
	while (list ($key, $val) = each ($_POST))
    {
    	if(in_array($key,$cansels)=='')
        {
        	$count++;
            if($count>1){$res=$res."&";}
            $res=$res.$key."=".$val;
        }
	}
    return $res;
}
function all_GETs($cansels=array('')) //������ ������, ���������� ��� ������� ������� $_GET � ����������� "&" ����� ������������� � ������� $cansels
{
	$res="";
    reset ($_GET);
    $count=0;
	while (list ($key, $val) = each ($_GET))
    {
    	if(in_array($key,$cansels)=='')
        {
        	$count++;
            if($count>1){$res=$res."&";}
            $res=$res.$key."=".$val;
        }
	}
    return $res;
	
}

?>