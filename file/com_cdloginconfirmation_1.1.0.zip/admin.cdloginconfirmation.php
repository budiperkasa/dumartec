<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla 
 * @subpackage	Login Confirmation
 * @category	Component
 * @version		1.1.0
 * @copyright	Copyright (C) 2007 - 2008 Core Design, http://www.greatjoomla.com
 * @license		http://creativecommons.org/licenses/by-nc/3.0/legalcode Creative Commons
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

$document =& JFactory::getDocument();
$document->addStyleSheet( JURI::root(true).'/administrator/components/com_cdloginconfirmation/assets/css/css.css' );

// require helpers
require_once( JPATH_COMPONENT.DS.'helpers'.DS.'cdloginconfirmation.php' );

// require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
$controller = JRequest::getWord('controller', 'default');
// Require specific controller if requested
if($controller) {
	require_once (JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php');
}
// Create the controller
$classname	= 'CdLoginConfirmationController'.$controller;
$controller = new $classname();

$task = ( JRequest::getCmd('task') ? JRequest::getCmd('task'): 'authorization' );
switch ($task) {	
	default:
		$controller->execute($task); // perform the Request task
		break;
}

// Redirect if set by the controller
$controller->redirect();

?>
