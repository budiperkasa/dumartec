<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class CdLoginConfirmationController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display() {
		parent::display();
	}
}
?>
