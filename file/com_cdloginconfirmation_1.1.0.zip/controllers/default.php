<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class CdLoginConfirmationControllerDefault extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function __construct() {
		parent::__construct();

		/* Redirect templates to templates as this is the standard call */
		$this->registerTask( 'authorization', 'display' );
		$this->registerTask( 'home', 'display' );
		$this->registerTask( 'configuration', 'display' );
	}

	/**
	 * Display function
	 */
	function display() {
		
		$task = ($this->getTask() ? $this->getTask() : 'authorization');
		
		$model =& $this->getModel('default'); // get actual model

		JRequest::setVar('view', 'default');

		$key_length = CdLoginConfirmationHelper::getParams('key_length', 5);
		$confirmation_method = CdLoginConfirmationHelper::getParams('confirmation_method', 'email');
		$session_attempt = CdLoginConfirmationHelper::getParams('session_attempt', 3);
		$send_mail = CdLoginConfirmationHelper::getParams('send_mail', 0);
		
		$isSessionEnable = $model->isSessionEnable();
		
		if (!$isSessionEnable or !$task) {
			JRequest::setVar('layout', 'authorization');
			JRequest::setVar('hidemainmenu', 1);
			$task = 'authorization';
		}
		switch ($task) {
			case 'home':				
				if (!$isSessionEnable) {
					$this->setRedirect('index.php?option=com_cdloginconfirmation', JText::_('CDLOGINCONFIRMATION_ACCESS_DENIED'), 'error');
				} else {					
					JRequest::setVar('layout', 'home');
					JSubMenuHelper::addEntry(JText::_('CDLOGINCONFIRMATION_HOME'), 'index.php?option=com_cdloginconfirmation');				
					JSubMenuHelper::addEntry(JText::_('CDLOGINCONFIRMATION_CONFIGURATION'), 'index.php?option=com_cdloginconfirmation&task=configuration');
				}
				
				break;
			case 'authorization':
				if (!$isSessionEnable) {
					
					$key_post_by_user = $model->keyPostByUser();
						
					$accessKeyRoutine = $model->accessKeyRoutine($key_length, $confirmation_method);
					
					if ($accessKeyRoutine) {
						if ($key_post_by_user) {
							if (!$model->compareKey($key_length, $session_attempt, $send_mail)) {
								$this->setRedirect('index.php?option=com_cdloginconfirmation', JText::_('CDLOGINCONFIRMATION_ACCESS_DENIED'), 'error');
							} else {
								CdLoginConfirmationHelper::clearSession(array('CdLoginConfirmationAccessKey', 'CdLoginConfirmationBlockSession'));
								$this->setRedirect('index.php', JText::_('CDLOGINCONFIRMATION_ACCESS_ALLOWED'), 'notice');
							}
						}
					}
				} else {
					$this->setRedirect('index.php?option=com_cdloginconfirmation&task=home');
				}
				break;
			case 'configuration':
				if (!$isSessionEnable) {
					$this->setRedirect('index.php?option=com_cdloginconfirmation', JText::_('CDLOGINCONFIRMATION_ACCESS_DENIED'), 'error');
				} else {					
					JRequest::setVar('layout', 'configuration');
					JSubMenuHelper::addEntry(JText::_('CDLOGINCONFIRMATION_HOME'), 'index.php?option=com_cdloginconfirmation');
					JSubMenuHelper::addEntry(JText::_('CDLOGINCONFIRMATION_CONFIGURATION'), 'index.php?option=com_cdloginconfirmation&task=configuration');
				}
				break;
			default:
				$this->setRedirect('index.php?option=com_cdloginconfirmation');
				break;
		}

		parent::display();
	}
	
	/**
	 * Logout user
	 */
	function logout() {
		global $mainframe;

		$mainframe->logout();
		$this->setRedirect('index.php?option=com_login');
	}
}
?>
