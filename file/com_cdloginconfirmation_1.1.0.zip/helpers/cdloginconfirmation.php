<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

class CdLoginConfirmationHelper {
	
	/**
	 * Send confirmation e-mail
	 */
	function emailConfirm($secure_link, $key_length = 5) {
		global $mainframe;
		 
		if (!$secure_link) {
			$secure_link = CdLoginConfirmationHelper::randomString($key_length); // generate again if not exists
		}
		 
		// send e-mail
		$config = & JFactory::getConfig();
		$user = & JFactory::getUser();
		
		
		$sender = array($config->getValue('mailfrom'), $config->getValue('fromname'));
		$recepient = $user->email;
        $subject = JText::_('CDCONFIRMATION_EMAIL_SUBJECT');
            
        $body = JText::sprintf('CDCONFIRMATION_EMAIL_BODY', $secure_link);
            
        $sent = CdLoginConfirmationHelper::sendEmail($sender, $recepient, $subject, $body);
        
        if ($sent) {
        	return true;
        } else {
        	return false;
        }
	}
	
	/**
     * Send e-mail wrapper
	 */
    function sendEmail($sender = array(), $recipient = '', $subject = '', $body = '') {
    	$message =& JFactory::getMailer();
		$message->addRecipient($recipient);
		$message->setSubject($subject);
		$message->setBody($body);
		$message->setSender($sender);
		$sent = $message->send();
		
		if (is_object($sent)) {
			return false;
		} else {
			return true;
		}
    }
    
	/**
	 * Create a Random String
	 *
	 * Useful for generating passwords or hashes.
	 *
	 * @access	public
	 * @param	string 	type of random string.  Options: alunum, numeric, nozero, unique
	 * @param	integer	number of characters
	 * @return	string
	 */
	function randomString($length = 5)
	{
		$alphanum = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		$var_random = '';
		mt_srand(10000000 * (double)microtime());
		for ($i = 0; $i < $length; $i++)
		$var_random .= $alphanum[mt_rand(0, 61)];
		return $var_random;
	}
	
	/**
     * Wrapper function to delete the specified session
     */
    function clearSession($name) {
    	
    	if (!$name) {
    		return;
    	}
    	
    	$session = &JFactory::getSession();
    	
    	if (is_array($name)) {
    		foreach ($name as $sessionname) {
    			$session->clear($sessionname); // clear session
    		}
    	} else {
    		$session->clear($name); // clear session
    	}
    }
    
	/**
     * Session attempt checker
     *
     * @access	public
     * @return	void
     */
    function sessionAttempt($session_attempt = 3, $count = 0, $send_mail =
        0)
    {
        global $mainframe;

        $live_path = JURI::base(); // define live site

        $session = &JFactory::getSession();

        if ($session_attempt == 0)
        {
            return;
        }

        if ($count < $session_attempt)
        {
            // nothing to do...
        } elseif ($count == $session_attempt and $send_mail)
        {
            jimport('joomla.mail.helper');

            // set date
            $config = &JFactory::getConfig();
            jimport('joomla.utilities.date');
            $date = new JDate(time(), $config->getValue('config.offset'));
            $date = $date->toFormat();
            // end
            
            $user = JFactory::getUser();
            
            $sender = array($config->getValue('mailfrom'), $config->getValue('fromname'));
            $recepient = $user->email;
            $subject = JText::sprintf('CDCONFIRMATION_EMAIL_ATTEMPT_SUBJECT');
            
            $body = '';
            $body .= JText::sprintf('CDCONFIRMATION_EMAIL_ATTEMPT_BODY') .
            $body .= "\r\n\r\n";
            $body .= JText::sprintf('CDCONFIRMATION_EMAIL_ATTEMPT_BODY_WEBSITES');
            $body .= ' ';
            $body .= $live_path;
            $body .= "\r\n";
            $body .= JText::sprintf('CDCONFIRMATION_EMAIL_ATTEMPT_BODY_USERNAME');
            $body .= ' ';
            $body .= $user->username;
            $body .= "\r\n";
            $body .= JText::sprintf('CDCONFIRMATION_EMAIL_ATTEMPT_BODY_TIME');
            $body .= ' ';
            $body .= $date;
            
            $sent = CdLoginConfirmationHelper::sendEmail($sender, $recepient, $subject, $body);			
            
            if (!$sent) {
            	JError::raiseNotice(500, JText::_('CDCONFIRMATION_EMAIL_NOT_SEND'));
            }
            
            $mainframe->logout();

        } elseif ($count > $session_attempt)
        {
            $mainframe->logout();
        }
    }
    
 	/**
     * Get components parameters
	 */
    function getParams($paramname, $default) {
    	if (!$paramname) {
    		return;
    	}
    	$params = &JComponentHelper::getParams( 'com_cdloginconfirmation' ); // component params
		$paramvalue = $params->get($paramname, $default);
		
		return $paramvalue;
    }
    
}

?>
