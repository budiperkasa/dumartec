<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');


if (!defined('_SUCCESS_INSTALL')) {
	define('_SUCCESS_INSTALL', 'Thank you choose Core Design extension!');
}
if (!defined('_PLG_SYSTEM_FOLDER_PATH')) {
	define('_PLG_SYSTEM_FOLDER_PATH', dirname(dirname(dirname(dirname(__FILE__)))) . DS . 'plugins' . DS . 'system');
}

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

function com_install()
{	
	$message = false;
	
	$plugin_file_exists = JFile::exists(_PLG_SYSTEM_FOLDER_PATH . DS . 'cdloginconfirmation.php');
	
	if (!$plugin_file_exists) {
		$install = installPlugin('cdloginconfirmation', 'system');
		if (!$install) {
			JError::raiseWarning('', 'Error! Please reinstall the component!');
		} else {
			$message = true;
		}
	}
        
	if ($message) {
		enableSession();
		echo _SUCCESS_INSTALL;
	}
}

function installPlugin($plugin, $plugin_folder) {
	
	if (!cleanPlugin($plugin, $plugin_folder)) {
		return false;
	}
	
	$db = & JFactory::getDBO();
	$query = 'INSERT INTO `#__plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES'
        . ' (0, '. $db->Quote('System - Core Design Login Confirmation plugin') .', '. $db->Quote($plugin) .', '. $db->Quote($plugin_folder) .', 0, 0, 1, 0, 0, 0, '. $db->Quote('0000-00-00 00:00:00') .', \'\');';
	$db->setQuery($query);
	
	if (!$db->query()) {
		return false;
	}
	
	$copy_files = copyFiles($plugin);
	
	if (!$copy_files) {
		return false;
	}
	
	$set_params = setParams();
	
	if (!$set_params) {
		return false;
	}
	
	return true;
}

function setParams() {
	$db = & JFactory::getDBO();
	$query = 'UPDATE `#__components` SET `params` = \'confirmation_method=email'
        . '\nkey_length=5'
        . '\nsession_attempt=3'
        . '\nsend_mail=0\' WHERE `#__components`.`option` LIKE \'com_cdloginconfirmation\' LIMIT 1;'; 
	$db->setQuery($query);
	
	if (!$db->query()) {
		return false;
	}
	return true;
}

function cleanPlugin($plugin, $plugin_folder) {
	$plugin_folder_path = _PLG_SYSTEM_FOLDER_PATH . DS . $plugin;
	$plugin_files_path = array(_PLG_SYSTEM_FOLDER_PATH . DS . "$plugin.php", _PLG_SYSTEM_FOLDER_PATH . DS. "$plugin.xml");
	
	if (JFolder::exists($plugin_folder_path)) {
		if (!JFolder::delete($plugin_folder_path)) {
			return false;
		}
	}
	
	foreach($plugin_files_path as $file_path) {
		if (JFile::exists($file_path)) {
			JFile::delete($file_path);
		}
	}
	
	$db = & JFactory::getDBO();
	
	$query_select = 'SELECT * FROM `#__plugins` WHERE `element` LIKE ' . $db->Quote($plugin) . ' AND `folder` LIKE ' . $db->Quote($plugin_folder) . ' LIMIT 0, 1 ';
	$db->setQuery($query_select);
	$query_select = $db->loadResult();
	
	if ($db->query() and $query_select) {
		$query_delete = 'DELETE FROM `#__plugins` WHERE `element` LIKE ' . $db->Quote($plugin) . ' AND `folder` LIKE ' . $db->Quote($plugin_folder) . '';
		$db->setQuery($query_delete);
		
		if (!$db->query()) {
			return false;
		}
	}
	return true;
}

function copyFiles($plugin) {
	
	$folder = JFolder::copy(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_' . $plugin . DS . 'plugin' . DS . $plugin, _PLG_SYSTEM_FOLDER_PATH . DS . $plugin);
	$file_php = JFile::copy(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_' . $plugin . DS . 'plugin' . DS . $plugin . '.php', _PLG_SYSTEM_FOLDER_PATH . DS . $plugin . '.php');
	$file_xml = JFile::copy(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_' . $plugin . DS . 'plugin' . DS . $plugin . '.xml', _PLG_SYSTEM_FOLDER_PATH . DS . $plugin . '.xml');
	$plg_lang = JFile::copy(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_' . $plugin . DS . 'language' . DS . 'plugin' . DS . 'en-GB.plg_system_cdloginconfirmation.ini', JPATH_ADMINISTRATOR . DS . 'language' . DS . 'en-GB' . DS . 'en-GB.plg_system_cdloginconfirmation.ini');
	
	if ($folder and $file_php and $file_xml and $plg_lang) {
		return true;
	} else {
		return false;
	}
}

function enableSession() {
	$session = &JFactory::getSession();
	$session->set('CdLoginConfirmationSessionEnable', 1); // set entrance session to 1
}

?>