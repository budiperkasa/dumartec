<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.model' );

class CdLoginConfirmationModelDefault extends JModel
{
	/**
	 * Check if access session is enabled
	 */
	function isSessionEnable() {
		global $mainframe;
		
		$session = &JFactory::getSession();
		
		$session_enable = $session->get('CdLoginConfirmationSessionEnable', 0); // retrieve info about enabled entrance

		if (isset($session_enable) and $session_enable == 1)
		{
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check if access key was setup, if not, "send" script is initiated
	 */
	function accessKeyRoutine($key_length = 5, $confirmation_method = 'email') {
		global $mainframe;
		
		$error = false;
		
		$session = &JFactory::getSession();

		$accessKey = $this->retrieveAccessKey();

		if (!isset($accessKey))
		{
			
			$secure_link = CdLoginConfirmationHelper::randomString($key_length); // generate key
			$session->set('CdLoginConfirmationAccessKey', $secure_link); // save generated key to session
			
			switch ($confirmation_method) {
				case 'email':
					if (!CdLoginConfirmationHelper::emailConfirm($secure_link, $key_length)) {
						JError::raiseNotice(500, JText::_('CDCONFIRMATION_EMAIL_NOT_SEND'));
					}
					break;
				default:
					return false;
					break;
			}
			return false;
		} else {
			return true;
		}
	}

	

	/**
	 * Compare received key
	 */
	function compareKey($key_length = 5, $session_attempt = 3, $send_mail = 0) {
		global $mainframe;
		
		$session = &JFactory::getSession();
		
		$key_post_by_user = $this->keyPostByUser();
		 
		if (isset($key_post_by_user))
		{
			// Check for request forgeries
			if (!JRequest::checkToken()) {
				jexit( 'Invalid Token' );
			}
			
			$accessKey = $this->retrieveAccessKey();
			
			if (preg_match('#^[a-zA-Z0-9]{' . $key_length . '}$#', $key_post_by_user)) {
				if ($key_post_by_user == $accessKey)
				{
					$session->set('CdLoginConfirmationSessionEnable', 1); // set entrance session to 1
				} else
				{
					$sessionAttempt = 1;
				}
			} else {
				$sessionAttempt = 1;
			}

			if ($sessionAttempt) {
				$session->set('CdLoginConfirmationSessionEnable', 0); // set entrance session to 0

				$blockSession = $session->get('CdLoginConfirmationBlockSession', 0); // retrieve info about enabled entrance
				
				$session->set('CdLoginConfirmationBlockSession', ++$blockSession); // set entrance session to 0
				
				CdLoginConfirmationHelper::sessionAttempt($session_attempt, $blockSession, $send_mail);
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}
    
    /**
     * Get key post by user (form)
     */
    function keyPostByUser($name = 'received_key') {
    	jimport('joomla.enviroment.request');
    	$key = JRequest::getVar($name, null, 'POST');
    	return $key;
    }
    
    /**
     * Retrieve access key from session
     */
    function retrieveAccessKey($name = 'CdLoginConfirmationAccessKey') {
    	$session = &JFactory::getSession();
    	$accessKey = $session->get($name, null); // get generated key from session
    	return $accessKey;
    }
}