<?php
/**
 * Core Design Login Confirmation plugin for Joomla! 1.5
 * @author		Daniel Rataj, <info@greatjoomla.com>
 * @package		Joomla 
 * @subpackage	System
 * @category	Plugin
 * @version		1.1.0
 * @copyright	Copyright (C) 2007 - 2008 Core Design, http://www.greatjoomla.com
 * @license		http://creativecommons.org/licenses/by-nc/3.0/legalcode Creative Commons
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import library dependencies
jimport('joomla.plugin.plugin');
jimport('joomla.enviroment.request'); // URL manipulation
// end

/**
 * Joomla! Core Design Login Confirmation plugin
 *
 * @author		Daniel Rataj <info@greatjoomla.com>
 * @package		Core Design
 * @subpackage	System
 */
class plgSystemCdLoginconfirmation extends JPlugin
{
    /**
     * Constructor
     *
     * For php4 compatability we must not use the __constructor as a constructor for plugins
     * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
     * This causes problems with cross-referencing necessary for the observer design pattern.
     *
     * @access	protected
     * @param	object		$subject The object to observe
     * @since	1.0
     */
    function plgSystemCdLoginconfirmation(&$subject)
    {
        parent::__construct($subject);

        // load plugin parameters
        //$this->plugin = &JPluginHelper::getPlugin('system', 'cdloginconfirmation');
        //$this->params = new JParameter($this->plugin->params);
    }
    
    /**
     * Call plgSystemCdLoginconfirmation
     */
    function onAfterRender() {
    	global $mainframe;
	    
	    // check if admin interface
        if (!$this->isAdmin()) {
        	return;
        }

        $user = JFactory::getUser();

        // check if user is logged or not
        if ($user->guest)
        {
            return;
        }
        unset($user);
        
        //JPlugin::loadLanguage('plg_system_cdloginconfirmation');
        
        $session = &JFactory::getSession();       

        $session_enable = $session->get('CdLoginConfirmationSessionEnable',
            0); // retrieve info about enabled entrance

        // check if session exists in database and is valid
        if (isset($session_enable) and $session_enable == 1)
        {
            return;
        }
        unset($session);
        
        if (!preg_match('#index\.php\?option=com_cdloginconfirmation$#', JRequest::getUri())) {
	    	$this->confirmRedirect();
	    }
    }
    
    /**
     * Redirect wrapper
	 */
    function confirmRedirect($url = 'index.php?option=com_cdloginconfirmation') {
    	global $mainframe;
    	$mainframe->redirect($url);
    }
    
    /**
     * Admin "is mainframe?" checker
	 */
    function isAdmin() {
    	global $mainframe;
    	
    	if ($mainframe->isAdmin()) {
    		return true;
    	} else {
    		return false;
    	}
    }
}
?>
