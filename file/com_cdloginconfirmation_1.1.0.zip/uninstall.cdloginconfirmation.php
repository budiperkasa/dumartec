<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

$message = '
<h3>Thank you for using Core Design extensions!</h3>
<p>We are constantly trying to improve our products. If you are no longer using our extension, please indicate the reason for removing the extension from your Joomla! installation.
</p>
<p>Our forum: <a href="http://www.greatjoomla.com/forum/" title="Open in new window" target="_blank">http://www.greatjoomla.com/forum/</a></p>
<p>Thank you for taking the time to share your feedback. Your comments and suggestions will help us to serve you better. </p>
';

if (!defined('_SUCCESS_UNINSTALL')) {
	define('_SUCCESS_UNINSTALL', $message);
}
if (!defined('_PLG_SYSTEM_FOLDER_PATH')) {
	define('_PLG_SYSTEM_FOLDER_PATH', dirname(dirname(dirname(dirname(__FILE__)))) . DS . 'plugins' . DS . 'system');
}

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

function com_uninstall() {
	$message = false;
	
	$uninstall = uninstallPlugin('cdloginconfirmation', 'system');
	if (!$uninstall) {
		JError::raiseWarning('', 'Error!');
	} else {
		$message = true;
	}
	
	if ($message) {
		//clearSession();
		echo _SUCCESS_UNINSTALL;
	}
}

function uninstallPlugin($plugin, $plugin_folder) {
	
	$plugin_folder_path = _PLG_SYSTEM_FOLDER_PATH . DS . $plugin;
	$plugin_files_path = array(_PLG_SYSTEM_FOLDER_PATH . DS . "$plugin.php", _PLG_SYSTEM_FOLDER_PATH . DS. "$plugin.xml", JPATH_ADMINISTRATOR . DS . 'language' . DS . 'en-GB' . DS . 'en-GB.plg_system_cdloginconfirmation.ini');
	
	if (JFolder::exists($plugin_folder_path)) {
		if (!JFolder::delete($plugin_folder_path)) {
			return false;
		}
	}
	
	foreach($plugin_files_path as $file_path) {
		if (JFile::exists($file_path)) {
			JFile::delete($file_path);
		}
	}
	
	$db = & JFactory::getDBO();
	
	$query_select = 'SELECT * FROM `#__plugins` WHERE `element` LIKE ' . $db->Quote($plugin) . ' AND `folder` LIKE ' . $db->Quote($plugin_folder) . ' LIMIT 0, 1 ';
	$db->setQuery($query_select);
	$query_select = $db->loadResult();
	
	if ($db->query() and $query_select) {
		$query_delete = 'DELETE FROM `#__plugins` WHERE `element` LIKE ' . $db->Quote($plugin) . ' AND `folder` LIKE ' . $db->Quote($plugin_folder) . '';
		$db->setQuery($query_delete);
		
		if (!$db->query()) {
			return false;
		}
	}
	return true;	
}

function clearSession() {
	$session = &JFactory::getSession();
	$session->clear('CdLoginConfirmationSessionEnable'); // clear session
}
?>