<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

?>

<?php
$document = &JFactory::getDocument(); // set document for next usage
$focus_script = "<script type=\"text/javascript\">
	<!--
	function setFocus() {
		document.cdloginconfirmation.received_key.select();
		document.cdloginconfirmation.received_key.focus();		
	}
	onload = function() {
		setFocus();
	}
	function checkForm() {
		if (document.cdloginconfirmation.received_key.value == '') {
			alert('". JText::_('CDLOGINCONFIRMATION_EMPTYKEY') ."');
			setFocus();
		} else {
			document.cdloginconfirmation.submit();
		}
	}
	// -->
</script>\n";
$document->addCustomTag($focus_script);
?>

<div class="cdloginconfirmation_wrapper">
	<div class="cdloginconfirmation_left_box_white">
		<div class="cdloginconfirmation_lefttop_box_white">
			<span class="cdloginconfirmation_topright_box_white">&nbsp;</span>
		</div>
		<div class="cdloginconfirmation_right_box_white">
			<div class="cdloginconfirmation_text_box_white">
				<p><?php echo JText::_('CDLOGINCONFIRMATION_PRETEXT_EMAIL');; ?></p>
				<form id="cdloginconfirmation" name="cdloginconfirmation" method="post" action="index.php" onsubmit="checkForm(); return false;">
				  	<div class="received_key">
					  	<label for="received_key">
						<?php echo JText::_('CDLOGINCONFIRMATION_RECEIVED_KEY'); ?>
						<input type="text" name="received_key" id="received_key" maxlength="30" title="<?php echo JText::_('CDLOGINCONFIRMATION_RECEIVED_KEY'); ?>" />
						</label>
					</div>
					<div class="submit">
						<input type="submit" title="<?php echo JText::_('CDLOGINCONFIRMATION_CONFIRM_BUTTON'); ?>" value="<?php echo JText::_('CDLOGINCONFIRMATION_CONFIRM_BUTTON'); ?>" />
					</div>
					<input type="hidden" name="option" value="com_cdloginconfirmation" />
					<input type="hidden" name="task" value="authorization" />
					<input type="hidden" name="controller" value="default" />
				  <?php echo JHTML::_( 'form.token' ); ?>
				</form>
			</div>
		</div>
		<div class="bottomleft_box_white">
			<span class="bottomright_box_white">&nbsp;</span>
		</div>
	</div>
	<div class="cdconfirmation_logout"><a href="index.php?option=com_cdloginconfirmation&task=logout" title="<?php echo JText::_('CDLOGINCONFIRMATION_LOGOUT'); ?>"><?php echo JText::_('CDLOGINCONFIRMATION_LOGOUT'); ?></a></div>
</div>