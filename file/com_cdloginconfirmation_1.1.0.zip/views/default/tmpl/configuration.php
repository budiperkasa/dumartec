<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<?php echo JText::sprintf('CDLOGINCONFIRMATION_CONFIGURATION_PRETEXT', JText::_('PARAMETERS')); ?>