<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<div class="cdlogincofirmation_home_wrapper">
	<div class="inner">
		Hello, <br />
		Thanks you choose Core Design extension!<br />
		<h3>About</h3>
		<p>A simple and effective component which adds an additional layer of security to your Joomla! administration.
		This component sends to your e-mail address (after successfully login) a confirmation message with the security code.
		The administration is locked until you enter the code.</p>
		<h3>Links</h3>
		<p><a href="http://www.greatjoomla.com/" target="_blank"
			title="Core Design Homepage">Core Design Homepage</a><br />
		<a href="http://www.greatjoomla.com/tutorials/index.html"
			target="_blank" title="Tutorials">Tutorials</a><br />
		<a
			href="http://www.greatjoomla.com/information/support/support-index.html"
			target="_blank" title="Support">Support</a></p>
	</div>
</div>
