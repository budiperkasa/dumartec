<?php
/**
 * Core Design Login Confirmation component for Joomla! 1.5
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );

class CdLoginConfirmationViewDefault extends JView {
	
	function display($tpl = null) {
		
		/* Get the task */
		$model =& $this->getModel('default'); // get actual model
		$isSessionEnable = $model->isSessionEnable();
		
		$task = ( !$isSessionEnable ? 'authorization' : JRequest::getCmd('task', 'authorization') );
		
		/* Get the toolbar */
		$this->toolbar($task);

		/* Assign variable - custom wrapper */
		//$this->assignRefWrapper($task);
		
		/* Display the page */
		parent::display($tpl);
	}
	
	function toolbar($task) {
		switch ($task) {
			case 'home':
				JToolBarHelper::title(JText::_( 'CDLOGINCONFIRMATION_COMPONENTTITLE_HOME' ), 'cdloginconfirmation-home' );
				break;
			case 'authorization':
				JToolBarHelper::title(JText::_( 'CDLOGINCONFIRMATION_COMPONENTTITLE_AUTH' ), 'cdloginconfirmation' );
				break;
			case 'configuration':
				JToolBarHelper::preferences( 'com_cdloginconfirmation', '250' );
				JToolBarHelper::title(JText::_( 'CDLOGINCONFIRMATION_COMPONENTTITLE_CONFIG' ), 'cdloginconfirmation-configuration' );
				break;
			default:
				die('Restricted access');
				break;
		}
	}
	
	/**
	 * Assign variable 
	 */
	function assignRefWrapper($task) {
		$model =& $this->getModel('default'); // get actual model
		switch ($task) {
			default:
				break;
		}
	}
}
?>
