<?php 
/**
* @version $Id: admin.categories.html.php 4070 2006-06-20 16:09:29Z stingrey $
* @package Joomla RE
* @subpackage Categories
* @localized ��������� ����� (C) 2006 Joom.Ru - ������� ��� Joomla!
* @copyright ��������� ����� (C) 2005 Open Source Matters. ��� ����� ��������.
* @license �������� http://www.gnu.org/copyleft/gpl.html GNU/GPL, �������� LICENSE.php
* Joomla! - ��������� ����������� �����������. ��� ������ ����� ���� ��������
* � ������������ � ����������� ������������ ��������� GNU, ������� ��������
* � ���������� ��������������� � ������� ���������� ������, ����������������
* �������� ����������� ������������ ��������� GNU ��� ������ �������� ��������� 
* �������� ��� �������� � �������� �������� �����.
* ��� ��������� ������������ � ��������� �� ��������� �����, �������� ���� COPYRIGHT.php.
* 
* @translator Oleg A. Myasnikov aka Sourpuss (sourpuss@mail.ru)
*/

// ������ ������� �������
defined( '_VALID_MOS' ) or die( 'UnAuthorized Access' );

/**
* @package Joomla RE
* @subpackage Categories
*/
class Jguard_html {

 	function show_options()
	{
    global $database,$mosConfig_live_site;
		$database->setQuery("select * from #__jguard_options");
		$data=$database->loadAssocList();
   	print '<div style="color:#'.$_GET[color].'"><b>'.$_GET[message].'</b></div>';
		?>
		<table class="adminheading">
			<tr>
				<th class="frontpage" style='background-image:url(images/config32.gif);'><?php print OPTIONS_HEADER;?></th>
			</tr>
		</table>
		
		<script language="Javascript" src="<?php  echo $mosConfig_live_site;?>/includes/js/overlib_mini.js"></script>
		<form action="index2.php" method="post" name="adminForm" style="display:inline;">
			<table class="adminform">
				<tr>
					<th>
						<?php print OPTIONS_PARAMETER;?>
					</th>
				</tr>
				<tr><td>
<!-- ������ -->
<script language='javascript'>
function send_email_close()
									{
										document.getElementById("params[email]").disabled=true;
										document.getElementById("params[send_php_injection]0").disabled=true;
										document.getElementById("params[send_php_injection]1").disabled=true;
										document.getElementById("params[send_mysql_injection]0").disabled=true;
										document.getElementById("params[send_mysql_injection]1").disabled=true;
										document.getElementById("params[send_flood]0").disabled=true;
										document.getElementById("params[send_flood]1").disabled=true;
										document.getElementById("send_email_table").style.color="#999999";
									}
									function send_email_open()
									{
										document.getElementById("params[email]").disabled=false;
										document.getElementById("params[send_php_injection]0").disabled=false;
										document.getElementById("params[send_php_injection]1").disabled=false;
										document.getElementById("params[send_mysql_injection]0").disabled=false;
										document.getElementById("params[send_mysql_injection]1").disabled=false;
										document.getElementById("params[send_flood]0").disabled=false;
										document.getElementById("params[send_flood]1").disabled=false;
										document.getElementById("send_email_table").style.color="#000000";
									}
									function mysql_open(){
										document.getElementById("params[mysql_parameter]0").disabled=false;
										document.getElementById("params[mysql_parameter]1").disabled=false;
										document.getElementById("params[mysql_parameter]2").disabled=false;
										document.getElementById("params[mysql_parameter]3").disabled=false;
                    document.getElementById("params[mysql_keywords]").disabled=false;
										document.getElementById("mysql_table").style.color="#000000";
									}
									function mysql_close(){
										document.getElementById("params[mysql_parameter]0").disabled=true;
										document.getElementById("params[mysql_parameter]1").disabled=true;
										document.getElementById("params[mysql_parameter]2").disabled=true;
										document.getElementById("params[mysql_parameter]3").disabled=true;
                    document.getElementById("params[mysql_keywords]").disabled=true;
										document.getElementById("mysql_table").style.color="#999999";
									}
</script>
					<table width="100%" class="paramlist" >
					<tr>
						<td colspan="2" style="padding-left:50px;"><div style="padding:5px;width:100%; border-bottom:2px solid #be4c34;background:#d7d7d7"><b><?php print OPT_MYSQL_TITLE;?></b>
							<?php
      							if ($data[0][mysql_scan]==1){ 
      							print '<input type="radio" name="params[mysql_scan]" value="1" checked="checked" onClick="mysql_open();"/> Yes';
      							print "<input type='radio' name='params[mysql_scan]' value='0' onClick='mysql_close();' /> No";
      							} else {  
      							print "<input type='radio' name='params[mysql_scan]' value='1' onClick='mysql_open();'/> Yes";
      							print "<input type='radio' name='params[mysql_scan]' value='0' checked='checked' onClick='mysql_close();' /> No ";
							}	?>
							</td>
						</tr>
						<tr>
						<td colspan='2'>
						<table id='mysql_table' width='100%' style='margin-left:40px;'>
						<tr><td>
							<table>
						<tr>
						<td valign='top' width='10' align='right'>
						<input type='checkbox' name='params[mysql_parameter0]' value='0' id='params[mysql_parameter]0'<?php print Jguard_html::check_mysql_parameter('0');?> /></td>
						<td>
                  <span class="editlinktip">
									<span onmouseover="return overlib('<?php print OPT_MYSQL_TO_LOG_DEF;?>', CAPTION, 'MySql injection', BELOW, RIGHT);" onmouseout="return nd();" ><p style='margin:0; padding:0; margin-bottom:3px;'>
                  <b><?php print OPT_MYSQL_TO_LOG;?> </b></p>
                  </span>
                  </span>
            </td>
            </tr>
						<tr>
						<td width='10'>
						<input type='checkbox' name='params[mysql_parameter1]' value='1' id='params[mysql_parameter]1'<?php print Jguard_html::check_mysql_parameter('1');?> /></td><td><span class="editlinktip"><span onmouseover="return overlib('<?php print OPT_MYSQL_SUSPECT_DEF;?>', CAPTION, 'MySql injection', BELOW, RIGHT);" onmouseout="return nd();" ><p style='margin:0; padding:0; margin-bottom:3px;'><b><?php print OPT_MYSQL_SUSPECT;?> </b></p></span></span></td></tr>
						<tr>
						<td>
						<input type='checkbox' name='params[mysql_parameter2]' value='2' id='params[mysql_parameter]2'<?php print Jguard_html::check_mysql_parameter('2');?> /></td><td><span class="editlinktip">
										<span onmouseover="return overlib('<?php print OPT_MYSQL_BLOCK_IP_DEF;?>', CAPTION, 'MySql injection', BELOW, RIGHT);" onmouseout="return nd();" ><p style='margin:0; padding:0; margin-bottom:3px;'><b><?php print OPT_MYSQL_BLOCK_IP;?></b></p></span></span></td></tr>
						<tr>
						<td>
						<input type='checkbox' name='params[mysql_parameter3]' value='3' id='params[mysql_parameter]3'<?php print Jguard_html::check_mysql_parameter('3');?> /></td><td><span class="editlinktip">
										<span onmouseover="return overlib('<?php print OPT_MYSQL_BLOCK_LOGIN_DEF;?>', CAPTION, 'MySql injection', BELOW, RIGHT);" onmouseout="return nd();" ><p style='margin:0; padding:0; margin-bottom:3px;'><b><?php print OPT_MYSQL_BLOCK_LOGIN;?> </b></p></span></span></td></tr>
            </td>
						<tr>
						</table>
						</td>
						<td align='center'>
						<span class="editlinktip">
										<span onmouseover="return overlib('<?php print OPT_MYSQL_KEYWORDS_DEF ;?>', CAPTION, 'MySql injection', BELOW, RIGHT);" onmouseout="return nd();" ><p style='margin:0; padding:0; margin-bottom:3px;'><b><?php print OPT_MYSQL_KEYWORDS;?></b></p></span></span>
						<p align='center'>
<textarea cols='70' rows='10' name='params[mysql_keywords]' id='params[mysql_keywords]'>
<?php
$text=$data[0][mysql_keywords];
print $text;
?>
</textarea>
</p>
							</td>
							</tr>
              <?php
              if ($data[0][mysql_scan]==0){
              ?>
              <script language='javascript'>
							document.getElementById("params[mysql_parameter]0").disabled=true;
							document.getElementById("params[mysql_parameter]1").disabled=true;
							document.getElementById("params[mysql_parameter]2").disabled=true;
							document.getElementById("params[mysql_parameter]3").disabled=true;
              document.getElementById("params[mysql_scan]").disabled=true;
							document.getElementById("mysql_table").style.color="#999999";
							</script>
              <?php
              }
              ?>
							</table>
							</td>
						</tr>
						<tr>
						
						
<!-- Untiflood -->
							<tr>
							<td colspan="2" style="padding-left:50px;"><div style="padding:5px;width:100%; border-bottom:2px solid #be4c34;background:#d7d7d7"><b><?php print OPT_ANTIFLOOD_TITLE;?></b>
								
								<input type="radio" name="params[untiflood]" id="params[untiflood]1" value="1" onClick="document.getElementById('params[flood_queries_1]').disabled=false;
		document.getElementById('params[flood_time_1]').disabled=false;
		if(document.getElementById('params[block_flood_else_1]1').checked)
		{
			document.getElementById('params[flood_queries_2]').disabled=false;
			document.getElementById('params[flood_time_2]').disabled=false;}
		else
		{
			document.getElementById('block_flood_else_1').style.color='#999999';
		}
		if(document.getElementById('params[block_flood_else_2]1').checked)
		{
			document.getElementById('params[flood_queries_3]').disabled=false;
			document.getElementById('params[flood_time_3]').disabled=false;
		}
		else
		{
			document.getElementById('block_flood_else_2').style.color='#999999';
		}
		document.getElementById('params[block_flood_else_1]0').disabled=false;
		document.getElementById('params[block_flood_else_1]1').disabled=false;
		document.getElementById('params[block_flood_else_2]0').disabled=false;
		document.getElementById('params[block_flood_else_2]1').disabled=false;
    document.getElementById('params[flood_parameter0]').disabled=false;
    document.getElementById('untiflood').style.color='#000000';" <?php  Jguard_html::state1($data[0],'untiflood');?> />
								Yes
                
    <input type="radio" name="params[untiflood]" id="params[untiflood]0" value="0" onClick="document.getElementById('params[flood_queries_1]').disabled=true;
		document.getElementById('params[flood_time_1]').disabled=true;
		document.getElementById('params[flood_queries_2]').disabled=true;
		document.getElementById('params[flood_time_2]').disabled=true;
		document.getElementById('params[flood_queries_3]').disabled=true;
		document.getElementById('params[flood_time_3]').disabled=true;
		document.getElementById('params[block_flood_else_1]0').disabled=true;
		document.getElementById('params[block_flood_else_1]1').disabled=true;
		document.getElementById('params[block_flood_else_2]0').disabled=true;
		document.getElementById('params[block_flood_else_2]1').disabled=true;
    document.getElementById('params[flood_parameter0]').disabled=true;
    document.getElementById('untiflood').style.color='#999999';" <?php  Jguard_html::state0($data[0][untiflood],'untiflood');?> />
								No</div></td>
						</tr>
                        
						<tr><td colspan=2>
                        <table class="paramlist" width='100%' id='untiflood' >
                        <tr>
                        <td>
                        <input type='checkbox' name='params[flood_parameter0]' id='params[flood_parameter0]' value='1' style='margin-left:50px;' <?php print Jguard_html::check_parameter('flood_parameter','1'); ?> >
                        <span onmouseover="return overlib('<?php print OPT_ANTIFLOOD_BLOCK_DEF ?>', CAPTION, 'Untiflood', BELOW, RIGHT);" onmouseout="return nd();" ><b style='margin-left:27px;'><?php print OPT_ANTIFLOOD_BLOCK ;?> </b></span></span>                        </td>
                        </tr>
                    
								<tr>
									<td width="40%" align="left" valign="top"  style="padding-left:100px;"><span class="editlinktip">
									<br />
										<span onmouseover="return overlib('<?php print OPT_ANTIFLOOD_IF_DEF ?>', CAPTION, 'Untiflood', BELOW, RIGHT);" onmouseout="return nd();" ><b><?php print OPT_ANTIFLOOD_IF ;?> </b></span></span></td>
									<td valign="bottom">
								</tr>
								<tr>
									<td style="padding-left:150px;"></td>
									<td><input type=text name="params[flood_queries_1]" id="params[flood_queries_1]" value="<?php  print $data[0][flood_queries_1];?>"> <?php print OPT_ANTIFLOOD_OR_MORE ?> <input type=text name="params[flood_time_1]" id="params[flood_time_1]" value="<?php  print $data[0][flood_time_1];?>"> <?php print OPT_ANTIFLOOD_SEC?>
										<hr />
									</td>
								</tr>
								<tr>
									<td width="40%" align="left" valign="top"  style="padding-left:100px;"><span class="editlinktip">
										<span onmouseover="return overlib('<?php print OPT_ANTIFLOOD_IF_DEF ?>', CAPTION, 'Untiflood', BELOW, RIGHT);" onmouseout="return nd();" ><b><?php print OPT_ANTIFLOOD_AND_IF ?></b></span></span></td>
									<td valign="bottom">
										<input type="radio" name="params[block_flood_else_1]" id="params[block_flood_else_1]0" value="0" onClick="document.getElementById('params[flood_queries_2]').disabled=true;
		document.getElementById('params[flood_time_2]').disabled=true;
		document.getElementById('block_flood_else_1').style.color='#999999';" <?php  Jguard_html::state0($data[0],'block_flood_else_1');?> />
										off
										<input type="radio" name="params[block_flood_else_1]" id="params[block_flood_else_1]1" value="1" onClick="document.getElementById('params[flood_queries_2]').disabled=false;
		document.getElementById('params[flood_time_2]').disabled=false;
		document.getElementById('block_flood_else_1').style.color='#000000';" <?php  Jguard_html::state1($data[0],'block_flood_else_1');?> />
										on
										</td>
								</tr>
								<tr id="block_flood_else_1">
									<td style="padding-left:150px;"></td>
									<td><input type=text name="params[flood_queries_2]" id="params[flood_queries_2]" value="<?php print $data[0][flood_queries_2];?>" > <?php print OPT_ANTIFLOOD_OR_MORE ?> <input type=text name="params[flood_time_2]" id="params[flood_time_2]" value="<?php print $data[0][flood_time_2]/60;?>" > <?php print OPT_ANTIFLOOD_MIN ?>)
										<hr />
									</td>
								</tr>
								<tr>
									<td width="40%" align="left" valign="top"  style="padding-left:100px;"><span class="editlinktip">
										<span onmouseover="return overlib('<?php print OPT_ANTIFLOOD_IF_DEF ?>', CAPTION, 'Untiflood', BELOW, RIGHT);" onmouseout="return nd();" ><b><?php print OPT_ANTIFLOOD_AND_IF ?></b></span></span></td>
									<td valign="bottom">
										<input type="radio" name="params[block_flood_else_2]" id="params[block_flood_else_2]0" value="0" onClick="document.getElementById('params[flood_queries_3]').disabled=true;
		document.getElementById('params[flood_time_3]').disabled=true;
		document.getElementById('block_flood_else_2').style.color='#999999';" <?php Jguard_html::state0($data[0],'block_flood_else_2');?> />
										off
										<input type="radio" name="params[block_flood_else_2]" id="params[block_flood_else_2]1" value="1" onClick="document.getElementById('params[flood_queries_3]').disabled=false;
		document.getElementById('params[flood_time_3]').disabled=false;
		document.getElementById('block_flood_else_2').style.color='#000000';" <?php Jguard_html::state1($data[0],'block_flood_else_2');?> />
										on
										</td>
								</tr>
								<tr id="block_flood_else_2">
									<td style="padding-left:150px;"></td>
									<td><input type=text name="params[flood_queries_3]" id="params[flood_queries_3]" value="<?php print $data[0][flood_queries_3];?>" > <?php print OPT_ANTIFLOOD_OR_MORE ?> <input type=text name="params[flood_time_3]" id="params[flood_time_3]" value="<?php print $data[0][flood_time_3]/3600;?>"> <?php print OPT_ANTIFLOOD_HOUR ?> 
										<hr />
									</td>
								</tr>
                                
                        </tr>
                        </td>
						</table><?php if($data[0][flood_queries_2]<=0 || $data[0][flood_time_2]<=0){print
		"<script language='JavaScript'>document.getElementById('params[flood_queries_2]').disabled=true;
		document.getElementById('params[flood_time_2]').disabled=true;
		document.getElementById('block_flood_else_1').style.color='#999999';</script>";}?>
								<?php if($data[0][flood_queries_3]<=0 || $data[0][flood_time_3]<=0)
								{print
		"<script language='JavaScript'>document.getElementById('params[flood_queries_3]').disabled=true;
		document.getElementById('params[flood_time_3]').disabled=true;
		document.getElementById('block_flood_else_2').style.color='#999999';</script>";}?>
										<?php if($data[0][untiflood]<=0)
										{print"<script language='JavaScript'>
		document.getElementById('params[flood_queries_1]').disabled=true;
		document.getElementById('params[flood_time_1]').disabled=true;
		document.getElementById('params[flood_queries_2]').disabled=true;
		document.getElementById('params[flood_time_2]').disabled=true;
		document.getElementById('params[flood_queries_3]').disabled=true;
		document.getElementById('params[flood_time_3]').disabled=true;
		document.getElementById('params[block_flood_else_1]0').disabled=true;
		document.getElementById('params[block_flood_else_1]1').disabled=true;
		document.getElementById('params[block_flood_else_2]0').disabled=true;
		document.getElementById('params[block_flood_else_2]1').disabled=true;
    document.getElementById('params[flood_parameter0]').disabled=true;
    document.getElementById('untiflood').style.color='#999999'; </script>";}?>
      </td></tr>
        <tr>
 <!-- ������������ ������ �� ������� ��������: -->         
          <td colspan="2" style="padding-left:50px;"><div style="padding:5px;width:100%; border-bottom:2px solid #be4c34;background:#d7d7d7"><b>
          <?php print OPT_FILE_TITLE ?></b>
          <script language='javascript'>
              function file_scan_open(){
              document.getElementById("params[file_parameter]0").disabled=false;
							document.getElementById("params[file_parameter]1").disabled=false;
							document.getElementById("file_table").style.color="#000000";
							}
              function file_scan_close(){
              document.getElementById("params[file_parameter]0").disabled=true;
							document.getElementById("params[file_parameter]1").disabled=true;
							document.getElementById("file_table").style.color="#999999";
              }
              </script>
								<?php if($data[0][file_scan]==0)
										{print"<script language='JavaScript'>document.getElementById('params[file_parameter]0').disabled=true;
							document.getElementById('params[file_parameter]1').disabled=true;
							document.getElementById('file_table').style.color='#999999'; </script>";
              
							print "<input type='radio' name='params[file_scan]' value='1' onClick='file_scan_open();'/> Yes";
							print "<input type='radio' name='params[file_scan]' value='0' checked='checked' onClick='file_scan_close();' /> No";
              
							}else{
							
							print "<input type='radio' name='params[file_scan]' value='1' checked='checked' onClick='file_scan_open();'/> Yes";
							print "<input type='radio' name='params[file_scan]' value='0'  onClick='file_scan_close();' /> No";
							}	?></td>
              
						</tr>
          <tr>
          <td colspan='2'>
          <table style='margin-left:50px;' id='file_table'>
						<tr>
						<td valign='top' width='10' align='right'>
						<input type='checkbox' name='params[file_parameter0]' value='0' id='params[file_parameter]0'<?php print Jguard_html::check_parameter('file_parameter','0');?> /></td>
						<td><p style='margin:0; padding:0; margin-bottom:3px;'><span onmouseover="return overlib(' <?php print OPT_FILE_BLOCK_LOGIN_DEF ?>', CAPTION, 'MySQL Parameter', BELOW, RIGHT);" onmouseout="return nd();" ><b> <?php print OPT_FILE_BLOCK_LOGIN ?></b></span></td></tr>
						<tr>
						<td width='10'>
						<input type='checkbox' name='params[file_parameter1]' value='1' id='params[file_parameter]1' <?php print Jguard_html::check_parameter('file_parameter','1');?> /></td><td><p style='margin:0; padding:0; margin-bottom:3px;'><p style='margin:0; padding:0; margin-bottom:3px;'><span onmouseover="return overlib('<?php print OPT_FILE_BLOCK_IP_DEF ?>', CAPTION, 'MySQL Parameter', BELOW, RIGHT);" onmouseout="return nd();" ><b><?php print OPT_FILE_BLOCK_IP ?></b>
            </td>
            </tr>
            <?php if($data[0][file_scan]==0)
							{print"<script language='JavaScript'>document.getElementById('params[file_parameter]0').disabled=true;
							document.getElementById('params[file_parameter]1').disabled=true;
							document.getElementById('file_table').style.color='#999999'; </script>";
              			
							}	?>
						</table>
          </td>
          </tr>
          </td>
						<tr>
<!-- ��������� Email �������������� � ������ ��������� ����: -->
							<td colspan="2" style="padding-left:50px;"><div style="padding:5px;width:100%; border-bottom:2px solid #be4c34;background:#d7d7d7"><b><?php print OPT_MAIL_TITLE;?></b>
							
								<input type="radio" name="params[send_email]" id="params[send_email]1" value="1" onClick=" send_email_open();" <?php Jguard_html::state1($data[0],'send_email');?> />
                Yes
                <input type="radio" name="params[send_email]" id="params[send_email]0" value="0" onClick=" send_email_close();" <?php Jguard_html::state0($data[0],'send_email');?> />
								No
								</div></td>
						</tr>
			
						<tr><td colspan=2>
						<table width=100% id="send_email_table" >
							<tr>
								<td width="40%" align="left" valign="top"  style="padding-left:100px;"><span class="editlinktip">
									<span onmouseover="return overlib('<?php print OPT_MAIL_EMAIL_DEF;?>', CAPTION, 'Email', BELOW, RIGHT);" onmouseout="return nd();" ><b>Email</b></span></span></td>
								<td valign="bottom">
									<input type=text name="params[email]" id="params[email]" value="<?php print $data[0][email];?>" >
									</td>
							</tr>
							<tr>
								<td width="40%" align="left" valign="top"  style="padding-left:100px;"><span class="editlinktip">
									<span onmouseover="return overlib('<?php print OPT_MAIL_DEF;?>', CAPTION, 'Email', BELOW, RIGHT);" onmouseout="return nd();" ><b><?php print OPT_MAIL_PHP;?></b></span></span></td>
								<td valign="bottom">
									<input type="radio" name="params[send_php_injection]" id="params[send_php_injection]0" value="0" <?php Jguard_html::state0($data[0],'send_file_injection');?> />
									No
									<input type="radio" name="params[send_php_injection]" id="params[send_php_injection]1" value="1" <?php Jguard_html::state1($data[0], 'send_file_injection');?> />
									Yes
									</td>
							</tr>
							<tr>
								<td width="40%" align="left" valign="top"  style="padding-left:100px;"><span class="editlinktip">
									<span onmouseover="return overlib('<?php print OPT_MAIL_DEF;?>', CAPTION, 'Email', BELOW, RIGHT);" onmouseout="return nd();" ><b><?php print OPT_MAIL_MYSQL;?></b></span></span></td>
								<td valign="bottom">
									<input type="radio" name="params[send_mysql_injection]" id="params[send_mysql_injection]0" value="0" <?php Jguard_html::state0($data[0],'send_mysql_injection');?> />
									No
									<input type="radio" name="params[send_mysql_injection]" id="params[send_mysql_injection]1" value="1" <?php Jguard_html::state1($data[0],'send_mysql_injection');?> />
									Yes
									</td>
							</tr>
							<tr>
								<td width="40%" align="left" valign="top"  style="padding-left:100px;"><span class="editlinktip">
									<span onmouseover="return overlib('<?php print OPT_MAIL_DEF;?>', CAPTION, 'Email', BELOW, RIGHT);" onmouseout="return nd();" ><b><?php print OPT_MAIL_FLOOD;?></b></span></span></td>
								<td valign="bottom">
									<input type="radio" name="params[send_flood]" id="params[send_flood]0" value="0" <?php Jguard_html::state0($data[0],'send_flood');?> />
									No
									<input type="radio" name="params[send_flood]" id="params[send_flood]1" value="1" <?php Jguard_html::state1($data[0],'send_flood');?> />
									Yes
								</td>
							</tr>
							
						
							</table>
						</td></tr>
					</table>
				</td></tr>
			</table>
								
								<?php if($data[0][send_email]<=0){print" <script language='JavaScript'>send_email_close(); </script>";}?>
			<input type="hidden" name="option" value="com_jdefender" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="boxchecked" value="0" />
			<input type="hidden" name="link_boxchecked" value="0" />
			
			
		</form>
		<?php 
	}
	function state1($data,$parametr)
	{
		if($parametr=="block_flood_else_1" && ($data[flood_queries_2]>0 || $data[flood_time_2]>0))
		{
			print' checked="checked" ';
		}
		else if($parametr=="block_flood_else_2" && ($data[flood_queries_3]>0 || $data[flood_time_3]>0))
		{
			print' checked="checked" ';
		}
		else if($data[$parametr]==1)
		{
			print' checked="checked" ';
		}
		
	}
	function state0($data,$parametr)
	{
		if($parametr=="block_flood_else_1" && ($data[flood_queries_2]<=0 || $data[flood_time_2]<=0))
		{
			print' checked="checked" ';
		}
		else if($parametr=="block_flood_else_2" && ($data[flood_queries_3]<=0 || $data[flood_time_3]<=0))
		{
			print' checked="checked" ';
		}
		else if($data[$parametr]!=1)
		{
			print' checked="checked" ';
		}
	}
	
	function show_block_list($pageNav,$limit,$limitstart)
	{
		global $database;
		print '<div style="color:#'.$_GET[color].'"><b>'.$_GET[message].'</b></div>';
		?>
			
		<table class="adminheading">
			<tr>
				<th class="frontpage" style="background-image:url(components/com_jdefender/images/blocklist48.gif)"><?php print BLOCKED_TITLE;?></th>
			</tr>
		</table>
		<form action="index2.php" method="post" name="adminForm" style="display:inline;">
		<div align="right">
			<SELECT NAME="params_select" class="inputbox" onchange="document.adminForm.submit();">
				<OPTION VALUE=""><?php print BLOCKED_CHOOSE;?>
				<OPTION VALUE="all"><?php print BLOCKED_FILTER_ALL ;?>
				<OPTION VALUE="login"><?php print BLOCKED_FILTER_LOGIN;?>
				<OPTION VALUE="Ip">Ip
				<!-- <OPTION VALUE="get">get
				<OPTION VALUE="post">post -->
			</SELECT>
		</div><br>
		
			<?php 
				if($_POST[params_select] && $_POST[params_select]!="all")
				{
					$where="where `type`='".$_POST[params_select]."'";
				}
				$database->setQuery("select * from #__jguard_block_list ".$where." order by `type`desc limit ".$limitstart.", ".$limit."");
				$data=$database->loadObjectList();?>
			<table class="adminlist">
			<tr>
				<th width="20">
					#
				</th>
				<th width="20">
					<input type="checkbox" name="toggle" value="" onClick="checkAll(<?php print count($data);?>);" />
				</th>
				<th width="20%">
					<?php print BLOCKED_PARAM;?>
				</th>
				<th width="20%">
					<?php print BLOCKED_VALUE;?>
				</th>
				<th> &nbsp </th>
			</tr>
			<?php 
			$current_row=0;
			
			$k=0;
			foreach ( $data as $row )
			{
			$current_row++;
			?>
			<tr class="<?php print 'row'.$k;?>">
				<td>
					<?php print $pageNav->rowNumber($current_row-1);?>
				</td>
				<td>
					<input type="checkbox" id="cb<?php print ($current_row-1);?>" name="check_id[<?php print ($current_row-1);?>]" value="<?php print $row->id;?>" onclick="isChecked(this.checked);" />
				</td>
				<td align="left">
					<b><?php print $row->type;?></b>
				</td>
				<td nowrap align="left">
					<?php 
					if ($row->type=="login")
					{
						$database->setQuery("select `name` from #__users where `id`='".$row->value."'");
						$login = $database->loadResult();
						print $login;
					}
					else
					{
						print $row->value;
					}?>
				</td>
				<td> &nbsp </td>
			</tr>
			<?php 
				$k = 1 - $k;
			}?>
				<?php 
					print $pageNav->getListFooter();
				?>
			</table>
		<input type="hidden" name="option" value="com_jdefender" />
			<input type="hidden" name="show" value="<?php print $show?>" />
			<input type="hidden" name="task" value="block_list" />
			<input type="hidden" name="boxchecked" value="0" />
			<input type="hidden" name="link_boxchecked" value="0" />
			<input type="hidden" name="log_for_xajax" value="<?php print $log_type;?>" />
      </form><?php 
	}
	
	function show_log($pageNav,$limit,$limitstart,$filter='none', $filter2='none')
	{
		global $database;
		
			require ('xajax/xajax_core/xajax.inc.php');
			$xajax = new xajax('index3.php?option=com_jdefender&task=log_suspect&no_html=1');
			$xajax->registerFunction("show_card");
			//$xajax->processRequest();
			$xajax->registerFunction("block_param");
			$xajax->processRequest();
			$xajax->printJavascript('components/com_jdefender/xajax/');
			
			?>
				<script src="components/com_jdefender/lib/prototype.js" type="text/javascript"></script>
				<script src="components/com_jdefender/src/scriptaculous.js" type="text/javascript"></script>
				<script src="components/com_jdefender/src/unittest.js" type="text/javascript"></script>
			<?php 
		
		
		print '<div style="color:#'.$_GET[color].'"><b>'.$_GET[message].'</b></div>';
		?>
		
		<script language="Javascript" src="<?php  echo $mosConfig_live_site;?>/includes/js/overlib_mini.js"></script>
		
   
   
		<style>
			table.card{background:#f9f9f9;border: 1px solid #be4c34; width:30%;}
			table.card td{border-bottom: 1px solid #dddddd;}
			table.info{width:100%}
			table.info td{border:none;}
		</style>
		
		
		<table width="100%" border='0'><tr><td>
		<div id="card_table_div" style="display:none"><table id="card_table" cellpadding="3" cellspacing="0" class="card"  align="left">
				<tr >
					<td colspan=2 style="background:#e9e9e9;border-bottom: 1px solid #be4c34"><big><b style="color:#c64934"><?php print LOG_CARD_TITLE;?></b></big></td>
					<td style="cursor: pointer;background:#e9e9e9;border-bottom: 1px solid #be4c34" width="1%" align="right"><img src="images\close.png" onClick=" Effect.BlindUp('div_action'); Effect.BlindUp('card_table_div');; return false;" alt="Close"></td>
				</tr>
				<tr>
					<td colspan=3><div align="center" style="cursor: pointer;background:#f1f3f5;" id="td_action" colspan="2" style="color:#a64030" onMouseOver="document.getElementById('td_action').style.background='#f1e8e6'" onMouseOut="document.getElementById('td_action').style.background='#f1f3f5'" onclick="
			if(document.getElementById('div_action').style.display=='none')
			{Effect.BlindDown('div_action');; return false;}
			else
			{Effect.BlindUp('div_action');; return false;}
			"><b><?php print LOG_CARD_ACTIONS;?></b></div>
						<form action="index2.php" method="get" name="delete_similar" style="display:inline;">
							<div id="div_action" style="display:none;">

							</div>
							<input type="hidden" name="option" value="com_jdefender" />
							<input type="hidden" name="task" value="delete_similar" />
						</form>
					</td>
				</tr>
				<tr style="font-weight:bolder;">
					<td><?php print LOG_CARD_PARAM;?></td>
					<td><?php print LOG_CARD_VAL;?></td>
					<td>&nbsp</td>
				</tr>
				<tr>
					<td align="left"><i><b><?php print LOG_CARD_IP;?></b></i></td>
					<td><b><div id="ip_params" style="color:#c64934;"></div></b></td>
					<td>&nbsp</td>
				</tr>
				<tr >
					<td align="left"><i><b><?php print LOG_CARD_GET;?></b></i></td>
					<td><div id="get_params">&nbsp</div></td>
					<td>&nbsp</td>
				</tr>
				<tr >
					<td align="left"><i><b><?php print LOG_CARD_POST;?></b></i></td>
					<td><div id="post_params">&nbsp</div></td>
					<td>&nbsp</td>
				</tr>
				<tr>
					<td align="left"><i><b><?php print LOG_CARD_REFERER;?>:</b></i></td>
					<td><div id="referer_params">&nbsp</div></td>
					<td>&nbsp</td>
				</tr>
				<tr>
					<td align="left"><i><b><?php print LOG_CARD_LOGIN;?></b></i></td>
					<td><div id="login_params">&nbsp</div></td>
					<td>&nbsp</td>
				</tr>
		</table></div></td></tr><tr><td>
		
			<?php 
				if ($filter=='none' and $filter2=='none'){
				$database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log order by `ctime`desc limit ".$limitstart.", ".$limit."");
        }
        else if ($filter=='suspect' and $filter2=='none'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `suspect_reject`='suspect' order by  `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        else if ($filter=='reject' and $filter2=='none'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `suspect_reject`='reject' order by `ctime`desc limit ".$limitstart.", ".$limit."  ");
        }
        else if ($filter2=='mysql_injection' and $filter=='none'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='mysql injection' order by `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        else if ($filter2=='mysql_injection' and $filter=='reject'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='mysql injection' and `suspect_reject`='reject'order by `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        else if ($filter2=='mysql_injection' and $filter=='suspect'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='mysql injection' AND `suspect_reject`='suspect' order by `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        else if ($filter2=='php_injection' and $filter=='none'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='php injection' order by  `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        else if ($filter2=='php_injection' and $filter=='reject'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='php injection' order by  `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        else if ($filter2=='php_injection' and $filter=='suspect'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='php injection' and `suspect_reject`='suspect' order by  `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        else if ($filter2=='flood' and $filter=='none'){
        $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='flood' order by `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        else if ($filter2=='flood' and $filter=='reject'){
          $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='flood' and `suspect_reject`='reject'order by `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
         else if ($filter2=='flood' and $filter=='suspect'){
          $database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `type`='flood' and `suspect_reject`='suspect'order by `ctime`desc limit ".$limitstart.", ".$limit." ");
        }
        
        
        
				$data=$database->loadObjectList();?>
       <form action="index2.php" method="post" name="adminForm" id='adminForm'>
         
		
           <table  border='0' width='100%'>
      <tr>
          <td>
          <table class="adminheading" border='0'>
			<tr>
          <th class="frontpage" style='background-image:url(components/com_jdefender/images/log48.gif);'><?php print LOG_TITLE ?></th>
      </tr>
		</table>
          </td>
            
            <td  align='right' border='0'>
            <b><?php print LOG_FILTER;?></b>
        
            <select name="filter"onChange="document.adminForm.submit();" style='margin-left:10px;'>
            <option value="none" <?php print Jguard_html::show_selected('none');?>  ><?php print LOG_FILTER_REJECT_SUSPECT;?></option>
            <option value="suspect" <?php print Jguard_html::show_selected('suspect');?> ><?php print LOG_FILTER_SUSPECT;?></option>
            <option value="reject" <?php print Jguard_html::show_selected('reject');?> ><?php print LOG_FILTER_REJECT;?></option>
            </select>
            <select name="filter2"onChange="document.adminForm.submit();">
            <option value="none" <?php print Jguard_html::show_selected('none');?>  ><?php print LOG_FILTER_TYPE;?></option>
            <option value="mysql_injection" <?php print Jguard_html::show_selected('mysql_injection');?>  ><?php print LOG_FILTER_MYSQL;?></option>
            <option value="php_injection" <?php print Jguard_html::show_selected('php_injection');?> ><?php print LOG_FILTER_PHP;?></option>
            <option value="flood" <?php print Jguard_html::show_selected('flood');?> ><?php print LOG_FILTER_FLOOD;?></option>
            </select>  
        </td>
      </tr>
      </table>
      <table class="adminlist" border='0'>
			<tr>
				<th width="20">
					#
				</th>
				<th width="20">
					<input type="checkbox" name="toggle" value="" onClick="checkAll(<?php print count($data);?>);" />
				</th>
				<th>
				<?php print LOG_SUSPECT_REJECT;?>
				</th>
				<th>
				<?php print LOG_IP;?>
				</th>
				<th>
					<?php print LOG_DATE;?>
				</th>
				<th>
					<?php print LOG_URL;?>
				</th>
				<th>
					<?php print LOG_POST;?>
				</th>
				<th>
					<?php print LOG_REFERER;?>
				</th>
				<th>
					<?php print LOG_LOGIN;?>
				</th>
				<th>
					<?php print LOG_TYPE;?>
				</th>
			</tr>
			<?php 
			$current_row=0;
			
			$k=0;
			foreach ( $data as $row )
			{
			$current_row++;
			?>
			<tr class="<?php print 'row'.$k;?>">
				<td align='center'>
					<?php print $pageNav->rowNumber($current_row-1);?>
				</td>
				<td align='center'>
					<input type="checkbox" id="cb<?php print ($current_row-1);?>" name="check_id[<?php print ($current_row-1);?>]" value="<?php print $row->id;?>" onclick="isChecked(this.checked);" />
				</td>
				<td align='center'>
				<?php if($row->suspect_reject=='reject') {print "<img src='images/alrt.gif'>";}
        else if($row->suspect_reject=='suspect'){ print"<img src='images/suspect.gif'>";}
        ?>
				<td align='center'>
					<?php 
				if($row->suspect_reject=="suspect"){
					?><a href="javascript:void(0);" onclick=" xajax_show_card(<?php print $row->id;?>,'suspect'); Effect.BlindDown('card_table_div');; return false;"><?php print $row->ip;?></a>
				<?php 
				}else{print $row->ip;}
				?>
				</td>
				<td nowrap align='center'>
					<?php print $row->ctime;?>
				</td>
				<td align='center'>
					<span onmouseover="return overlib('<?php print $row->url;?>', CAPTION, 'url', BELOW, RIGHT);" onmouseout="return nd();" ><?php print Jguard_html::substr_ex($row->url);?></span>
				</td>
				<td align='center'>
					<span onmouseover="return overlib('<?php print $row->post;?>', CAPTION, 'post', BELOW, RIGHT);" onmouseout="return nd();" ><?php print Jguard_html::substr_ex($row->post);?></span>
				</td>
				<td align='center'>
					<span onmouseover="return overlib('<?php print $row->referer;?>', CAPTION, 'referer', BELOW, RIGHT);" onmouseout="return nd();" ><?php print Jguard_html::substr_ex($row->referer);?></span>
				</td>
				<td align='center'>
					<?php 
					$database->setQuery("select `name` from #__users where `id`='".$row->user_id."'");
					$login = $database->loadResult();
					print $login;
					?>
				</td>
				<td align='center'>
					<?php print $row->type;?>
				</td>
			</tr>
			<?php 
				$k = 1 - $k;
			}?>
				<?php 
					print $pageNav->getListFooter();
				?>
			</table>
			<input type="hidden" name="option" value="com_jdefender" />
			<input type="hidden" name="show" value="<?php print $show?>" />
			<input type="hidden" name="task" value="log_<?php print $log_type;?>" />
			<input type="hidden" name="boxchecked" value="0" />
			<input type="hidden" name="link_boxchecked" value="0" />
			<input type="hidden" name="log_for_xajax" value="<?php print $log_type;?>" />
		</form>
				</td></tr></table>
				<?php 
	 }
	function substr_ex($str)
	{
		$text=substr($str,0,35);
		if($str && strlen($str)>35)
		{
			$text.=" ...";
		}
		return $text;
	}
	function check_parameter($field_name,$value){
	global $database;
	$sql = "SELECT $field_name FROM #__jguard_options WHERE id=1";
	$database->setQuery($sql);
	$result=$database->loadAssocList();
		if (eregi($value,$result[0][$field_name])){
			return "checked='checked'";
		}
	}
	function check_mysql_parameter($value){
  global $database;
  $database->setQuery("SELECT mysql_parameter FROM #__jguard_options");
  $result = $database->loadAssocList();
  $result = $result[0][mysql_parameter];
  $values = explode(" ",$result);
      foreach ($values as $val){
        if($val==$value){
        return "checked='checked'";
        }
      }
  }
  function show_selected($value){
  if ($value==$_POST['filter'] or $_POST['filter2']==$value){
  return "selected='selected'";
  }
}
}

function block_param($id_img,$type,$value)
{
	global $database;
	$objResponse = new xajaxResponse();
	
	if($value)
	{
		$database->setQuery("select count(type) from #__jguard_block_list where `type`='".$type."' and `value`= '".$value."'");
		$count_rows = $database->loadResult();
		if($count_rows == 0)
		{
			$database->setQuery("insert into #__jguard_block_list (`type`, `value`) values ('".$type."','".$value."')");
			$database->query();
			$objResponse->assign($id_img,"src","components/com_jdefender/images/security_f2_tick1.gif");
		}
		else
		{
			$database->setQuery("DELETE FROM `#__jguard_block_list` WHERE `type`='".$type."' and `value`= '".$value."'");
			$database->query();
			$objResponse->assign($id_img,"src","components/com_jdefender/images/security_f2_open1.png");
		}
	}
	return $objResponse;
}
function show_card($id,$log)
{
	global $database;
	
	$database->setQuery("select *,DATE_FORMAT(`ctime`, '%e-%m-%Y <small><b>%k:%i</b></small>') as ctime from #__jguard_log where `id`='".$id."'");
	$data=$database->loadObjectList();
	$objResponse = new xajaxResponse();
	
	$database->setQuery("select `name` from #__users where `id`='".$data[0]->user_id."'");
	$login = $database->loadResult();
	
	$text='<div align=left><input type="checkbox" name="delete_all_similar_ip" id="similar_ip" value="'.$data[0]->ip.'">
								Delete all card with similar ip</div>';
	if($login)
	{
		$text.='					<div align=left><input type="checkbox" name="delete_all_similar_login" id="similar_login" value="'.$data[0]->user_id.'">
									Delete all card with similar login</div>';
	}
	else
	{
		$text.='					<div align=left><input type="checkbox" name="delete_without_login" id="similar_login" value="1">
									Delete all card without login</div>';
	}
	$text.='					<input type="submit" value="Execute">';
	$objResponse->assign("div_action","innerHTML",$text);
	
	
	$text="<table class='info' width=100%>";
	$database->setQuery("select * from #__jguard_block_list where `type`='ip' and `value`='".$data[0]->ip."'");
	$blocks=$database->loadObjectList();
	$OnClick=' onClick="document.getElementById(\'ip_img\').src=\'components/com_jdefender/images/load.gif\';xajax_block_param(\'ip_img\',\'ip\',\''.$data[0]->ip.'\');" ';
	if(count($blocks)>0){$image='<img alt="unblock" style="cursor: pointer;" id="ip_img" src="components/com_jdefender/images/security_f2_tick1.gif" '.$OnClick.'>';}
	else{$image='<img alt="block" style="cursor: pointer;" id="ip_img" src="components/com_jdefender/images/security_f2_open1.png" '.$OnClick.'>';}
	$text.="<tr><td align='left'> ".$data[0]->ip."</td><td align='right'>".$image."</td></tr>";
	$text.="</table>";
	$objResponse->assign("ip_params","innerHTML",$text);
	
	$text="<table class='info' width=100%>";
	$gets_str=parse_url($data[0]->url);
	
	if($gets_str["query"])
	{
		parse_str ($gets_str["query"], $gets_arr);
		print_array($gets_arr,0,$gets);
		
		//<img src="\administrator\components\com_jguard\images\security_f2_tick1.gif">
		//<img src="\administrator\components\com_jguard\images\security_f2_open1.png">
		$count_get=0;
		foreach ($gets as $get)
		{
			$count_get++;
			$database->setQuery("select * from #__jguard_block_list where `type`='get' and `value`='".$get."'");
			$blocks=$database->loadObjectList();
			$id_img='img_get'.$count_get;
			$OnClick=' onClick="document.getElementById(\''.$id_img.'\').src=\'components/com_jdefender/images/load.gif\';xajax_block_param(\''.$id_img.'\',\'get\',\''.$get.'\');" ';
			$image='';
			/*if(count($blocks)>0)
			{$image='<img alt="unblock" style="cursor: pointer;" id="'.$id_img.'" src="\administrator\components\com_jguard\images\security_f2_tick1.gif" '.$OnClick.'>';}
			else{$image='<img alt="block" style="cursor: pointer;" id="'.$id_img.'" src="\administrator\components\com_jguard\images\security_f2_open1.png" '.$OnClick.'>';}*/
			$text.="<tr><td align='left'>".$get."</td><td align='right'>".$image."</td></tr>";
		}
		
	}
	$text.="</table>";
	$objResponse->assign("get_params","innerHTML",$text);
		
	$text="<table class='info' width=100%>";
	if($data[0]->post)
	{
		parse_str ($data[0]->post, $posts_arr);
		print_array($posts_arr,0,$posts);
		
		foreach ($posts as $post)
		{
			$count_post++;
			$database->setQuery("select * from #__jguard_block_list where `type`='post' and `value`='".$post."'");
			$blocks=$database->loadObjectList();
			$id_img='img_post'.$count_post;
			$OnClick=' onClick="document.getElementById(\''.$id_img.'\').src=\'components/com_jdefender/images/load.gif\';xajax_block_param(\''.$id_img.'\',\'post\',\''.$post.'\');" ';
			$image='';
			/*if(count($blocks)>0){$image='<img alt="unblock" style="cursor: pointer;" id="'.$id_img.'" src="\administrator\components\com_jguard\images\security_f2_tick1.gif" '.$OnClick.'>';}
			else{$image='<img alt="block" style="cursor: pointer;" id="'.$id_img.'" src="\administrator\components\com_jguard\images\security_f2_open1.png" '.$OnClick.'>';}*/
			$text.="<tr><td align='left'>".$post."</td><td align='right'>".$image."</td></tr>";
		}
	}
	$text.="</table>";
	$objResponse->assign("post_params","innerHTML",$text);
	
	
	$text="<table class='info' width=100%>";
	if($data[0]->referer)
	{
		$referer=parse_url($data[0]->referer);
		$database->setQuery("select * from #__jguard_block_list where `type`='referer' and `value`='".$referer["host"]."'");
		$OnClick=' onClick="document.getElementById(\'img_referer\').src=\'components/com_jdefender/images/load.gif\';xajax_block_param(\'img_referer\',\'referer\',\''.$referer["host"].'\');" ';
		$blocks=$database->loadObjectList();
		if(count($blocks)>0){$image='<img alt="unblock" style="cursor: pointer;" id="img_referer" src="components/com_jdefender/images/security_f2_tick1.gif" '.$OnClick.'>';}
		else{$image='<img alt="block" style="cursor: pointer;" id="img_referer" src="components/com_jdefender/images/security_f2_open1.png" '.$OnClick.'>';}
		$text.="<tr><td align='left' nowrap> <span onmouseover= \"return overlib('".$data[0]->referer."', CAPTION, 'referer', BELOW, RIGHT);\" onmouseout=\"return nd();\" >".Jguard_html::substr_ex($data[0]->referer)."</span></td><td align='right'>".$image."</td></tr>";
	}
	$text.="</table>";
	$objResponse->assign("referer_params","innerHTML",$text);
	
	
	
	$text="<table class='info' width=100%>";
	$database->setQuery("select `name` from #__users where `id`='".$data[0]->user_id."'");
	$login = $database->loadResult();
	if($login)
	{
		$database->setQuery("select `name` from #__users where `id`='".$data[0]->user_id."'");
		$login = $database->loadResult();
		$OnClick=' onClick="document.getElementById(\'img_login\').src=\'components/com_jdefender/images/load.gif\';xajax_block_param(\'img_login\',\'login\',\''.$data[0]->user_id.'\');" ';
		$database->setQuery("select * from #__jguard_block_list where `type`='login' and `value`='".$data[0]->user_id."'");
		$blocks=$database->loadObjectList();
		if(count($blocks)>0){$image='<img alt="unblock" style="cursor: pointer;" id="img_login" src="components/com_jdefender/images/security_f2_tick1.gif" '.$OnClick.'>';}
		else{$image='<img alt="block" style="cursor: pointer;" id="img_login" src="components/com_jdefender/images/security_f2_open1.png" '.$OnClick.'>';}
		$text.="<tr><td align='left'>".$login."</td><td align='right'>".$image."</td></tr>";
	}
	$text.="</table>";
	$objResponse->assign("login_params","innerHTML",$text);
	
	return $objResponse;
}
function print_array($argument,$padding,&$ret_arr,$up_key=''){
	foreach($argument as $key => $get)
	{
		if(is_array($get))
		{
			print_array($get,$padding++,$ret_arr,$key);
		}
		else
		{ 
			if($up_key)
			{
				$t_var=$up_key.'=';
			}
			else
			{
				$t_var=$key.'=';
			}
			
			$t_var.=$get;
			$ret_arr[]=$t_var;
		}
	}
	return $ret_arr;
}
?>