<?php
/**
* @version $Id: admin.categories.php 4873 2006-08-31 17:26:11Z predator $
* @package Joomla RE
* @subpackage Categories
* @localized ��������� ����� (C) 2006 Joom.Ru - ������� ��� Joomla!
* @copyright ��������� ����� (C) 2005 Open Source Matters. ��� ����� ��������.
* @license �������� http://www.gnu.org/copyleft/gpl.html GNU/GPL, �������� LICENSE.php
* Joomla! - ��������� ����������� �����������. ��� ������ ����� ���� ��������
* � ������������ � ����������� ������������ ��������� GNU, ������� ��������
* � ���������� ��������������� � ������� ���������� ������, ����������������
* �������� ����������� ������������ ��������� GNU ��� ������ �������� ��������� 
* �������� ��� �������� � �������� �������� �����.
* ��� ��������� ������������ � ��������� �� ��������� �����, �������� ���� COPYRIGHT.php.
* 
* @translator Oleg A. Myasnikov aka Sourpuss (sourpuss@mail.ru)
* @translator Dmitry Hazin aka Denon (hazin_d@mail.ru)
*/

// ������ ������� �������
error_reporting(0);
defined( '_VALID_MOS' ) or die( '������ ���������' );

require_once( $mainframe->getPath( 'admin_html' ) );
if (file_exists( $mosConfig_absolute_path.'/administrator/components/com_jdefender/language/'.$mosConfig_lang.'.php' ))
    include( $mosConfig_absolute_path.'/administrator/components/com_jdefender/language/'.$mosConfig_lang.'.php' );
else
    require( $mosConfig_absolute_path.'/administrator/components/com_jdefender/language/english.php' );
$checked_box=mosGetParam( $_GET, 'boxchecked', '0' );
$show=mosGetParam( $_GET, 'show', '' );
define( 'COM_IMAGE_BASE', $mosConfig_absolute_path . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'stories' );

// get parameters from the URL or submitted form
$section 	= strval( mosGetParam( $_REQUEST, 'section', 'content' ) );

$cid 		= josGetArrayInts( 'cid' );

switch ($task) {
	case 'delete_similar':
		delete_similar("suspect");
		break;
	case 'log':
		$catid 		= intval( $mainframe->getUserStateFromRequest( "catid{$option}", 'catid', 0 ) );
		$limit 		= intval( $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mosConfig_list_limit ) );
		$limitstart = intval( $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 ) );
		
		$database->setQuery( "SELECT COUNT(*) FROM #__jguard_log" );
		$total = $database->loadResult();
		
		require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
		$pageNav = new mosPageNav( $total, $limitstart, $limit);
		if (!isset($_POST[filter])){$_POST[filter]='none';}
    if (!isset($_POST[filter2])){$_POST[filter2]='none';}
		Jguard_html::show_log($pageNav,$limit,$limitstart,$_POST[filter], $_POST[filter2]);
		break;
	case 'Options':
		Jguard_html::show_options();
		break;
	case 'save_options':
		validate();
		save_options();
		break;
	case 'block_list':
		$catid 		= intval( $mainframe->getUserStateFromRequest( "catid{$option}", 'catid', 0 ) );
		$limit 		= intval( $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mosConfig_list_limit ) );
		$limitstart = intval( $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 ) );
		
		$database->setQuery( "SELECT COUNT(*) FROM #__jguard_block_list" );
		$total = $database->loadResult();
		
		require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
		$pageNav = new mosPageNav( $total, $limitstart, $limit );
		
		Jguard_html::show_block_list($pageNav,$limit,$limitstart);
		break;
	case 'delete_suspect':
		delete_checked('suspect');
		break;
	case 'delete_all_suspect':
		delete_checked('suspect','all');
		break;
	case 'delete_reject':
		delete_checked('reject');
		break;
	case 'delete_all_reject':
		delete_checked('reject','all');
		break;
	case 'unblock_params':
		unblock_params();
		 break;
	case 'unblock_all_params':
		unblock_params("all");
		 break;
		/*case 'unblocking':
			unblocking_selected($checked_box,$show);
			break;
		case 'blocking_ip':
			blocking_ip($show);
			break;
		case 'unblocking_ip':
			unblocking_ip($show);
			break;
		case 'blocking_ip_selected':
			blocking_ip_selected($checked_box,$show);
			break;
		case 'unblocking_ip_selected':
			unblocking_ip_selected($checked_box,$show);
			break;*/
	default:
		$catid 		= intval( $mainframe->getUserStateFromRequest( "catid{$option}", 'catid', 0 ) );
		$limit 		= intval( $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mosConfig_list_limit ) );
		$limitstart = intval( $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 ) );
		
		$database->setQuery( "SELECT COUNT(*) FROM #__jguard_log" );
		$total = $database->loadResult();
		
		require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
		$pageNav = new mosPageNav( $total, $limitstart, $limit );
		if (!isset($_POST[filter])){$_POST[filter]='none';}
    if (!isset($_POST[filter2])){$_POST[filter2]='none';}
		Jguard_html::show_log($pageNav,$limit,$limitstart,$_POST[filter], $_POST[filter2]);
		break;
}
function unblock_params($what='')
{
	global $database;
	if($what=='')
	{
		foreach ( $_POST["check_id"] as $id )
		{
			$database->setQuery("DELETE FROM #__jguard_block_list WHERE `id`='".$id."'");
			$database->query();
		}
		$message="Parameters were unblocked successfully.";
		mosRedirect("index2.php?option=com_jdefender&task=block_list&color=488000&message=".$message);
	}
	else
	{
		$database->setQuery("DELETE FROM #__jguard_block_list");
		$database->query();
		
		$message="All parameters were unblocked successfully.";
		mosRedirect("index2.php?option=com_jdefender&task=block_list&color=488000&message=".$message);
	}
}
	
function delete_similar($log)
{
	global $database;
	if($_GET["delete_without_login"]==1)
	{
	/*IMPORTANT********************************
	*				IMPORTANT			*
	*******************************************/
		$database->setQuery("DELETE FROM `#__jguard_log` WHERE `user_id`= '0'");
		$database->query();

		$message="������ ������� �������.";
		mosRedirect("index2.php?option=com_jdefender&task=log_".$log."&color=488000&message=".$message);
	}
	if($_GET["delete_all_similar_ip"])
	{
		$database->setQuery("DELETE FROM `#__jguard_log` WHERE `ip`='".$_GET["delete_all_similar_ip"]."'");
		$database->query();
		
		$message="������ ������� �������.";
		mosRedirect("index2.php?option=com_jdefender&task=log&color=488000&message=".$message);
	}
	if($_GET["delete_all_similar_login"])
	{
		$database->setQuery("DELETE FROM `#__jguard_log` WHERE `user_id`= '".$_GET["delete_all_similar_login"]."'");
		$database->query();
		
		$message="������ ������� �������.";
		mosRedirect("index2.php?option=com_jdefender&task=log&color=488000&message=".$message);
	}
}
function delete_checked($log,$what="")
{
	global $database;
	if(!$what)
	{
		foreach ( $_POST["check_id"] as $id )
		{
			$database->setQuery("DELETE FROM #__jguard_log WHERE `id`='".$id."'");
			$database->query();
		}
		$message="Records were deleted successfully";
		mosRedirect("index2.php?option=com_jdefender&task=log&color=488000&message=".$message);
	}
	else
	{
		$database->setQuery("DELETE FROM #__jguard_log");
		$database->query();
		
		$message="All records were deleted successfullys";
		mosRedirect("index2.php?option=com_jdefender&task=log_".$log."&color=488000&message=".$message);
	}
}
function validate()
{
	if(		($_POST[params][untiflood]==1 && ((!is_numeric($_POST[params][flood_queries_1]) || $_POST[params][flood_queries_1]=="" || $_POST[params][flood_queries_1]==0) || (!is_numeric($_POST[params][flood_time_1]) || $_POST[params][flood_time_1]=="" || $_POST[params][flood_time_1]==0))) ||
			($_POST[params][block_flood_else_1]==1 && ((!is_numeric($_POST[params][flood_queries_2]) || $_POST[params][flood_queries_2]=="" || $_POST[params][flood_queries_2]==0) || (!is_numeric($_POST[params][flood_time_2]) || $_POST[params][flood_time_2]=="" || $_POST[params][flood_time_2]==0))) ||
			($_POST[params][block_flood_else_2]==1 && ((!is_numeric($_POST[params][flood_queries_3]) || $_POST[params][flood_queries_3]=="" || $_POST[params][flood_queries_3]==0) || (!is_numeric($_POST[params][flood_time_3]) || $_POST[params][flood_time_3]=="" || $_POST[params][flood_time_3]==0))))
	{
		
		$message=OPT_INCORRECT_ANTIFLOOD;
		mosRedirect("index2.php?option=com_jdefender&task=Options&color=c64934&message=".$message);
	}
	else {
		if($_POST[params][block_flood_else_1]==1 and  (is_numeric($_POST[params][flood_time_2])) and  (is_numeric($_POST[params][flood_queries_2]))){
			 $_POST[params][flood_time_2]*=60;
		}
		if($_POST[params][block_flood_else_2]==1 and  (is_numeric($_POST[params][flood_time_3])) and  (is_numeric($_POST[params][flood_queries_3]))){
			 $_POST[params][flood_time_3]*=3600;
		}
	}
	if($_POST[params][send_email]==1)
	{
		if($_POST[params][email]=='')
		{
			$message=OPT_EMAIL_REQUIRED;
			mosRedirect("index2.php?option=com_jdefender&task=Options&color=c64934&message=".$message);
		}
		if (!preg_match("/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i", $_POST[params][email]))
		{
			$message= OPT_INCORRECT_EMAIL; 
			mosRedirect("index2.php?option=com_jdefender&task=Options&color=c64934&message=".$message);
		}
	}
}
function save_options()
{
	global $database;
	print '<pre>';print_r($_POST);print '</pre>';
	$database->setQuery("select * from #__jguard_options");
	$data=$database->loadObjectList();
	if (count($data)==0)
	{
		$database->setQuery("insert into #__jguard_options (`id`) values ('1')");
		$database->query();
	}
 
    $mysql_parameter = $_POST[params][mysql_parameter0];
    $mysql_parameter.= " ".$_POST[params][mysql_parameter1];
		$mysql_parameter.= " ".$_POST[params][mysql_parameter2];
    $mysql_parameter.= " ".$_POST[params][mysql_parameter3];
    $file_parameter = $_POST[params][file_parameter0];
    $file_parameter.= " ".$_POST[params][file_parameter1];
    $update =" `mysql_scan` = '".$_POST[params][mysql_scan]."',";
		$update.=" `mysql_parameter` = '".$mysql_parameter."',";
		$update.=" `mysql_keywords`='".$_POST[params][mysql_keywords]."',";
		$update.=" `file_scan` = '".$_POST[params][file_scan]."',";
		$update.=" `file_parameter` ='".$file_parameter."',";
		$update.=" `untiflood` = '".$_POST[params][untiflood]."',";
    $update.=" `flood_queries_1` = '".$_POST[params][flood_queries_1]."',";
		$update.=" `flood_time_1` = '".$_POST[params][flood_time_1]."',";
		$update.=" `flood_queries_2` = '".$_POST[params][flood_queries_2]."',";
		$update.=" `flood_time_2` = '".$_POST[params][flood_time_2]."',";
		$update.=" `flood_queries_3` = '".$_POST[params][flood_queries_3]."',";
		$update.=" `flood_time_3` = '".$_POST[params][flood_time_3]."',";
		$update.=" `flood_parameter` ='".$_POST[params][flood_parameter0]."',";
    $update.=" `send_email` = '".$_POST[params][send_email]."',";
		$update.=" `send_file_injection` = '".$_POST[params][send_php_injection]."',";
		$update.=" `send_mysql_injection` = '".$_POST[params][send_mysql_injection]."',";
		$update.=" `send_flood` = '".$_POST[params][send_flood]."',";
		$update.=" `email` = '".$_POST[params][email]."'";
		
		$database->setQuery("UPDATE #__jguard_options set ".$update);
		$database->query();
		$message=OPT_SAVE_SUCCESS;
		mosRedirect("index2.php?option=com_jdefender&task=Options&color=488000&message=".$message);
}
/*function blocking_ip_selected($checked_box,$show)
{
	global $database;
	if($checked_box!=0)
	{
		$found=0;
		$count_chekboxs=0;
		while($found!=$checked_box){
			$count_chekboxs++;
			$current_ip=mosGetParam( $_GET, 'block_ip_'.$count_chekboxs,'');
			if($current_ip)
			{
				$found++;
				$database->setQuery("UPDATE #__jguard_log set block_ip=1 WHERE `id`='".$current_ip."'");
				$database->query();
			}
		}
	}
	mosRedirect("index2.php?option=com_jguard&task=show_log&show=".$show);
}

function unblocking_ip_selected($checked_box,$show)
{
	print'I here!';
	global $database;
	if($checked_box!=0)
	{
		$found=0;
		$count_chekboxs=0;
		while($found!=$checked_box){
			$count_chekboxs++;
			$current_ip=mosGetParam( $_GET, 'block_ip_'.$count_chekboxs,'');
			if($current_ip)
			{
				$found++;
				$database->setQuery("UPDATE #__jguard_log set block_ip=0 WHERE `id`='".$current_ip."'");
				$database->query();
			}
		}
	}
	mosRedirect("index2.php?option=com_jguard&task=show_log&show=".$show);
}

function blocking_ip($show)
{
	global $database;
	$database->setQuery("UPDATE #__jguard_log set block_ip=1 WHERE `id`='".$show."'");
	$database->query();
	mosRedirect("index2.php?option=com_jguard&task=show_log&show=".$show);
}
function unblocking_ip($show)
{
	global $database;
	$database->setQuery("UPDATE #__jguard_log set block_ip=0 WHERE `id`='".$show."'");
	$database->query();
	mosRedirect("index2.php?option=com_jguard&task=show_log&show=".$show);
}
function blocking_selected($checked_box,$show)
{
	global $database;
	if($checked_box!=0)
	{
		$found=0;
		$count_chekboxs=0;
		while($found!=$checked_box){
			$count_chekboxs++;
			$current_referer=mosGetParam( $_GET, 'block_referer_'.$count_chekboxs,'');
			$current_url=mosGetParam( $_GET, 'block_url_'.$count_chekboxs,'');
			if($current_referer)
			{
				$found++;
				$database->setQuery("UPDATE #__jguard_url_log set block_referer=1 WHERE `id`='".$current_referer."'");
				$database->query();
			}
			if($current_url)
			{
				$found++;
				$database->setQuery("UPDATE #__jguard_url_log set block_url=1 WHERE `id`='".$current_url."'");
				$database->query();
			}
		}
	}
	mosRedirect("index2.php?option=com_jguard&task=show_log&show=".$show);
}
function unblocking_selected($checked_box,$show)
{
	global $database;
	if($checked_box!=0)
	{
		$found=0;
		$count_chekboxs=0;
		while($found!=$checked_box){
			$count_chekboxs++;
			$current_referer=mosGetParam( $_GET, 'block_referer_'.$count_chekboxs,'');
			$current_url=mosGetParam( $_GET, 'block_url_'.$count_chekboxs,'');
			if($current_referer)
			{
				$found++;
				$database->setQuery("UPDATE #__jguard_url_log set block_referer=0 WHERE `id`='".$current_referer."'");
				$database->query();
			}
			if($current_url)
			{
				$found++;
				$database->setQuery("UPDATE #__jguard_url_log set block_url=0 WHERE `id`='".$current_url."'");
				$database->query();
			}
		}
	}
	mosRedirect("index2.php?option=com_jguard&task=show_log&show=".$show);
}*/
?>