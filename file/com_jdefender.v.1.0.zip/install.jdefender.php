<?php
/*
 * Installation procedure
 *
 * This file is responsible to install the component
 */

/**
* Function which installs the component and copies over some images needed
* to correctly display the navigation bar.
*/
function com_install() 
{
	global $database, $mosConfig_absolute_path, $mosConfig_mailfrom;

	// define array containing all the images to be copied over
	$images = array("delete_f2.png","deleteall_f2.png","save_f2.png","unblock2_f2.png","unblock2all_f2.png","alrt.gif","suspect.gif","close.png","config32.gif","log48.gif","blocklist48.gif");
	
	// copy over the images to its location
	foreach ($images as $file)
	{
		$dst = $mosConfig_absolute_path .'/administrator/images/'.$file;
		$src = $mosConfig_absolute_path .'/administrator/components/com_jdefender/images/'.$file;
		//print '<div>��'.$src.'�'.$dst.'</div>';
		if (!is_file($dst))
		{
			if (!copy($src, $dst ))
			{
				echo "Failed to copy $file from $src to $dst ...";
			}
		}
	}
	//echo "Installed Successfully";
  $icons = array("log16.gif","blocklist16.gif","defender16.gif");
  foreach($icons as $file){
  $dst = $mosConfig_absolute_path .'/includes/js/ThemeOffice/'.$file;
  $src = $mosConfig_absolute_path .'/administrator/components/com_jdefender/images/'.$file;
    if (!is_file($dst)){
      if(!copy($src,$dst)){
        echo "failed to Copy. $file from $src to $dst";
      }
    }
  }

changeIcon("JDefender","com_jdefender","js/ThemeOffice/defender16.gif");
changeIcon("Show log","com_jdefender",'js/ThemeOffice/log16.gif');
changeIcon("Block list","com_jdefender","js/ThemeOffice/blocklist16.gif");
changeIcon("Options","com_jdefender","js/ThemeOffice/config.png");
$database->setQuery("update #__jguard_options set `email`='".$mosConfig_mailfrom."' where id=1");
$database->query();
}

function changeIcon($name,$option,$icon,$newlink='') {
		global $database;
		$update= $newlink ? ' , `admin_menu_link` = \''.$database->getEscaped($newlink)."' " : '';
		$database->setQuery( "UPDATE #__components"
		."\n SET admin_menu_img = '".$icon."' ".$update
		."\n WHERE name = '".$name."' AND `option` = '".$option."'");
		if (!$database->query()) {
			echo $database->stderr();
      //BackToInstall($database->getErrorMsg());
		}
	}
  
?> 
