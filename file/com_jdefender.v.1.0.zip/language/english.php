<?php
//OPTIONS
define ('OPTIONS_HEADER','Options of Defence function');
define('OPTIONS_PARAMETER','Defence Parameters:');
// OPTIONS MYSQL
define('OPT_MYSQL_TITLE','MySql Injections Options');
define('OPT_MYSQL_TO_LOG', 'Write to Log as Suspect');
define('OPT_MYSQL_TO_LOG_DEF','Put a tick to let the program write into log when MySql injection is discovered. Will be written as Suspect.');
define('OPT_MYSQL_SUSPECT','Stop The Supposed Attack');
define('OPT_MYSQL_SUSPECT_DEF','Stops the MySql Attack and Writes to LOG as Reject.');
define('OPT_MYSQL_BLOCK_IP','Block the IP address');
define('OPT_MYSQL_BLOCK_IP_DEF','Blocking the IP address of the attacker and he/she is not able to enter the site.');
define('OPT_MYSQL_BLOCK_LOGIN','Block the Login (if exists)');
define('OPT_MYSQL_BLOCK_LOGIN_DEF', 'Blocking the Login of the Registered user if he/she comments an attack.');
define('OPT_MYSQL_KEYWORDS','Enter keywords and regular expressions for MySql scanner');
define('OPT_MYSQL_KEYWORDS_DEF','The words must be entered in the form of /someWord/ or you can enter preg_match regular expressions');
//OPTIONS ANTIFLOOD
define('OPT_ANTIFLOOD_TITLE','Antiflood');
define('OPT_ANTIFLOOD_IF','Block if');
define('OPT_ANTIFLOOD_IF_DEF','If the User brakes this rules and comments more queries in the defined time  he/she will be automatically blocked.');
define('OPT_ANTIFLOOD_OR_MORE','or more queries in');
define('OPT_ANTIFLOOD_SEC','second(s)');
define('OPT_ANTIFLOOD_MIN','minute(s)');
define('OPT_ANTIFLOOD_HOUR','hour(s)');
define('OPT_ANTIFLOOD_AND_IF','and if');
define('OPT_ANTIFLOOD_BLOCK','Block IP');
define('OPT_ANTIFLOOD_BLOCK_DEF','Blocks the IP if checked if not just stops the attack.');
//OPTIONS FILE SCAN
define('OPT_FILE_TITLE','File scan for PHP injections');
define('OPT_FILE_BLOCK_LOGIN','Block the Login (if exists)');
define('OPT_FILE_BLOCK_LOGIN_DEF','Scans the file inside for PHP injection and if finds stops the loading.');
define('OPT_FILE_BLOCK_IP','Block the IP');
define('OPT_FILE_BLOCK_IP_DEF','Scans the file inside for PHP injection and if finds stops the loading. And blocks the IP address of the Loader.');
//OPTIONS SENDIND EMAIL
define('OPT_MAIL_TITLE','Send mail to administrator in the case of following attacks');
define('OPT_MAIL_EMAIL_DEF','E-mail address of the administrator. To recieve the report.');
define('OPT_MAIL_PHP','PHP injections');
define('OPT_MAIL_DEF','If cheked an email will be sent.');
define('OPT_MAIL_MYSQL','MySql Injections');
define('OPT_MAIL_FLOOD','Flood');
define('OPT_SAVE_SUCCESS','The parameters were changed successfully.');
define('OPT_INCORRECT_EMAIL','The E-mail was enetered incorrect. Enter in the form of somemail@somemail.com');
define('OPT_INCORRECT_ANTIFLOOD','Incorrect Antiflood Parameters. All the values must be numeric.');
define('OPT_EMAIL_REQUIRED','An E-mail is a reqired field.');
//LOG

define('LOG_TITLE','The Log of the suspicious and rejected attacks');
define('LOG_CARD_TITLE','Record Card');
define('LOG_CARD_ACTIONS','Actions');
define('LOG_CARD_PARAM','Parameters');
define('LOG_CARD_VAL','Value');
define('LOG_CARD_IP','IP:');
define('LOG_CARD_GET','GET Values:');
define('LOG_CARD_POST','POST Values:');
define('LOG_CARD_REFERER','Referer:');
define('LOG_CARD_LOGIN','Login:');
define('LOG_FILTER','Filter:');
define('LOG_FILTER_REJECT_SUSPECT','Reject and Suspect');
define('LOG_FILTER_REJECT','Reject');
define('LOG_FILTER_SUSPECT','Suspect');
define('LOG_FILTER_TYPE','Select Type');
define('LOG_FILTER_MYSQL','Mysql Injections');
define('LOG_FILTER_PHP','PHP Injections');
define('LOG_FILTER_FLOOD','FLood');
define('LOG_SUSPECT_REJECT','Reaction Type');
define('LOG_DATE','Date');
define('LOG_URL','URL');
define('LOG_IP','IP');
define('LOG_POST','Post');
define('LOG_REFERER','Referer');
define('LOG_LOGIN','Login');
define('LOG_TYPE','Type');
//BLOCK LIST
define('BLOCKED_TITLE','The list of Blocked Users');
define('BLOCKED_PARAM','Parameter');
define('BLOCKED_VALUE','Value');
define('BLOCKED_CHOOSE','Choose the type of Parameter');
define('BLOCKED_FILTER_ALL','All Parameters');
define('BLOCKED_FILTER_LOGIN','Login');
define('BLOCKED_FILTER_IP','IP');





?>