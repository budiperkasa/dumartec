<?php
/*
 * Uninstall procedure
 *
 * This file is responsible to uninstall the component
 */
/**
* This function is responsible uninstalling the component.
*/ 
function com_uninstall()
{
	echo "Thank you for using this component.";
	// define array containing all the images to be deleted
	$images = array( "delete_f2.png","deleteall_f2.png","save_f2.png","unblock2_f2.png","unblock2all_f2.png");
	// copy over the images to its location
	foreach ($images as $file)
	{
		$dst = $mosConfig_absolute_path .'/administrator/images/'.$file;
		if (is_file($dst))
		{
			$deleted = unlink($dst);
			//echo "File ".$file.": ".$deleted;
			exit0;
		}
	}
unlink($mosConfig_absolute_path.'/includes/js/ThemeOffice/log16.gif');
unlink($mosConfig_absolute_path.'/includes/js/ThemeOffice/blocklist16.gif');
unlink($mosConfig_absolute_path.'/includes/js/ThemeOffice/defender16.gif');
unlink($mosConfig_absolute_path.'/administrator/images/alrt.gif');
unlink($mosConfig_absolute_path.'/administrator/images/suspect.gif');
unlink($mosConfig_absolute_path.'/administrator/images/close.png');
unlink($mosConfig_absolute_path.'/administrator/images/log48.gif');
unlink($mosConfig_absolute_path.'/administrator/images/blocklist48.gif');
}
?>