<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Album Manager Test</title>
</head>
<body bgcolor="#ffffff">
<div style="margin: auto;">
<?
function is__writable($path)
{

   if ($path{strlen($path)-1}=='/')
    
       return is__writable($path.uniqid(mt_rand()).'.tmp');
 
   else {
   
   if (ereg('.tmp', $path))
   {
    
       if (!($f = @fopen($path, 'w+')))
           return false;
       fclose($f);
       unlink($path);
       return true;

   }
   else {
   	if (!($f = @fopen($path, 'a')))
           return false;
       fclose($f);
       return true;
   }//We have a path error.
    }


}


	if (version_compare ('5.0.0', phpversion(), '<=') == 1 || function_exists (domxml_open_file)) {
		echo 'OK - DOMXML extension enabled';
	} else {
		echo '<font color=#ff3300>DOMXML extension unavailable</font>';
	}
	echo '<p></p>';
	if (function_exists (imagecreatefromjpeg)) {
		echo 'OK - GD extension enabled';
	} else {
		echo '<font color=#ff3300>GD extension unavailable</font>';
	}
	echo '<p></p>';
	if (is__writable(dirname(__FILE__).'/'.'../img/')) {
		echo 'OK - expose/img/ folder is writable (ensure all files in the folder are also writable)';
	} else {
		echo '<font color=#ff3300>expose/img/ folder is NOT writable. please set the correct permissions.</font>';
	}
	echo '<p></p>';
	if (is__writable(dirname(__FILE__).'/'.'../xml/')) {
		echo 'OK - expose/xml/ folder is writable (ensure all files in the folder are also writable)';
	} else {
		echo '<font color=#ff3300>expose/xml/ folder is NOT writable. please set the correct permissions.</font>';
	}
	echo '<p></p>';
	if (is__writable(dirname(__FILE__).'/'.'amfphp/extra/passhash.inc.php')) {
		echo 'OK - password file is writable';
	} else {
		echo '<font color=#ff3300>password file (expose/manager/amfphp/extra/passhash.inc.php) is NOT writable. please set the correct permissions.</font>';
	}
?>
</div>
</body>
</html>
