<?php
//****************************************************************************
//Component: Expose
//Version  : 1.0.0
//Author   : Josh
//E-Mail   : webmaster@gotgtek.com
//Web Site : www.gotgtek.com
//Copyright: Copyright 2006 by GTEK Technologies and Slooz.com
//License  : GNU General Public License (GPL), see http://www.slooz.com for details
//
//Joomla 1.x flash gallery component.
//****************************************************************************

function com_uninstall()
{
	echo( "Expose has been successfully uninstalled." );
}

?>