<?php

$target_path = "../../../components/com_expose/expose/img/";	

if (isset($_FILES['userfile'])) {
	$target_path = "../../../components/com_expose/expose/img/";	
	$target_path = $target_path. basename( $_FILES['userfile']['name']); 
	
	$userfile_name	= (isset($_FILES['userfile']['name']) ? $_FILES['userfile']['name'] : "");
	$filename = split("\.", $userfile_name);	
	
	
	if ((strcasecmp(substr($userfile_name,-4),'.jpg'))) {		
	echo "<script>alert('The file must be jpg'); document.location.href='uploadimg.php';</script>";
	} 
	
	
	if(!move_uploaded_file($_FILES['userfile']['tmp_name'], $target_path)) {
	    echo "<script>alert('Error uploading'); document.location.href='uploadimg.php';</script>";
	} else{	    
	    echo "<script>alert('File uploaded to $target_path'); document.location.href='uploadimg.php';</script>";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Upload a file</title>
</head>
<body>

<link rel="stylesheet" href="../../templates/khepri/css/template.css" type="text/css" />
<form method="post" action="uploadimg.php" enctype="multipart/form-data" name="filename">

<table class="adminform">
<tr>
	<th class="title"> 
		File Upload : <?php echo $target_path; ?>
	</th>
</tr>
<tr>
	<td align="center">
		<input class="inputbox" name="userfile" type="file" />
	</td>
</tr>
<tr>
	<td>
		<input class="button" type="submit" value="Upload" name="fileupload" />
		Max size = <?php echo ini_get( 'post_max_size' );?>
	</td>
</tr>
</table>

<input type="hidden" name="directory" value="<?php echo $directory;?>" />
</form>

</body>
</html>