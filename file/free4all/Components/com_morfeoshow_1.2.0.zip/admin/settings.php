<?php
/********************************************
* MorfeoShow  - Joomla! Component       	  
* Copyright (C) 2008 by www.joomlaitalia.com 
* --------- All Rights Reserved ------------ 
* Homepage   : www.joomlaitalia.com          
* License    : GNU/GPL License               
*********************************************/

defined('_JEXEC') or die( 'Direct Access to this location is not allowed.' );
$params_morfeo					= array();
$params_morfeo['googlekey']		= "";
$params_morfeo['user_id']			= "";
$params_morfeo['max_img']			= "51";
$params_morfeo['frontend']		= "1";
$params_morfeo['logo']			= "1";
$params_morfeo['minilistw']		= "50";
$params_morfeo['minilisth']		= "50";
$params_morfeo['minithumbw']		= "80";
$params_morfeo['minithumbh']		= "80";
$params_morfeo['minimainw']		= "180";
$params_morfeo['minimainh']		= "80";
$params_morfeo['imagesw']			= "640";
$params_morfeo['imagesh']			= "480";
$params_morfeo['cropw']			= "80";
$params_morfeo['croph']			= "80";
$params_morfeo['resizew']			= "180";
$params_morfeo['resizeh']			= "80";
$params_morfeo['shulang']			= "en";
$params_morfeo['shuadat']			= "shadowbox-base.js";
$params_morfeo['titolo']			= "1";
$params_morfeo['larghezza']		= "90";
$params_morfeo['back']			= "0";
$params_morfeo['gapi']			= "0";
$params_morfeo['orderback']		= "title asc";
$params_morfeo['flickrkey']		= "";
$params_morfeo['description']		= "0";
$params_morfeo['style']			= "0";
$params_morfeo['style0']			= "0";
$params_morfeo['style1']			= "";
$params_morfeo['style2']			= "";
$params_morfeo['maximgh']			= "480";
$params_morfeo['maximgw']			= "480";
$params_morfeo['txtcolor']		= "333333";
$params_morfeo['framecolor']		= "999999";
$params_morfeo['framewidth']		= "0";
$params_morfeo['stagepadding']	= "0";
$params_morfeo['navpadding']		= "40";
$params_morfeo['cols']			= "6";
$params_morfeo['rows']			= "2";
$params_morfeo['navpos']			= "bottom";
$params_morfeo['alignv']			= "center";
$params_morfeo['alignh']			= "center";
$params_morfeo['larfront']		= "100";
$params_morfeo['colonnefront']	= "5";
$params_morfeo['max_upload_size']  = "2000000";
?>