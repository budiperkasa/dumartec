DROP TABLE #__morfeoshow;
DROP TABLE #__morfeoshow_img;
DROP TABLE #__morfeoshow_rating;